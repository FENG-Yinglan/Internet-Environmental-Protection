﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

using ZXing;
using ZXing.Common;
using ZXing.QrCode;

namespace printting
{
    public partial class Form1 : Form
    {
        string title = "垃圾回收系统";

        string[] codes = { "12345678", "12345676" };
        string typesss = "可回收垃圾";
        int index = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.printDialog1.ShowDialog() == DialogResult.OK)
            {
                //PrinterSettings.PaperSizeCollection ps = printDialog1.PrinterSettings.PaperSizes;
                printDocument1.PrinterSettings = printDialog1.PrinterSettings;
                printDocument1.Print();
                //printDocument1.PrinterSettings
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.printDocument1.Print();
        }

        private void printDocument1_BeginPrint(object sender, PrintEventArgs e)
        {
            index = 0;
            //打印参数设置
            //PaperSize ps = new PaperSize("==", w, h);
            //ps.RawKind = 220;
            //printDocument1.DefaultPageSettings.PaperSize = ps;
            //printDocument1.DefaultPageSettings.Margins.Bottom = 0;
        }

        private void printDocument1_EndPrint(object sender, PrintEventArgs e)
        {
            index = 0;
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;
            //g.DrawLine(Pens.Black,105,105, 320, 31);
            //g.DrawLine(Pens.Black, 0, 0, 153, 114);
            int w= e.PageBounds.Width;
            int h = e.PageBounds.Height;
            //g.DrawImage(getBmp(w,h),0,0);
            
           if( index < codes.Length - 1)
            {
                e.HasMorePages = true;
            }
           else
            {
                e.HasMorePages = false;
            }
            g.DrawImage(getPrintBmp(codes, null, index, w, h), 0, 2);
            index++;

        }

        private Bitmap getBmp(int w,int h)
        {
            Bitmap bmp = new Bitmap(w, h);
            Graphics g = Graphics.FromImage(bmp);
            //g.DrawLine(Pens.Black,0,0,40,30);
            //g.DrawRectangle(Pens.Black, 0+5,0+2 , w-15, h-10);

            //g.DrawImage(getShowBitMap(w-15,h-10),5,2);
            g.DrawImage(getPrintBmp(codes,null,index,w,h),5,2);
            return bmp;
        }

        private Bitmap getShowBitMap(int w,int h)
        {
            Bitmap bmp = new Bitmap(w, h);
            Graphics g = Graphics.FromImage(bmp);
            Image img = Bitmap.FromFile("D:\\cc.jpg");
            g.DrawImage(img,0,0);
            return bmp;
        }


        private Bitmap getPrintBmp(string []codes,int []types,int i,int w,int h)
        {
            Bitmap bmp = new Bitmap(w,h);
            Graphics g = Graphics.FromImage(bmp);
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            g.DrawString(title, this.Font, Brushes.Black, new Rectangle(0, 0, w, (int)(h*0.25)), sf);
            int barH = (int)(h * 0.5);
            g.DrawImage(getCodeBmp(codes[i], w, barH), 0, (int)(h * 0.25));
            //g.DrawString(typesss, this.Font, Brushes.Black, new Rectangle(0, , w, (int)(h * 0.25)), sf);
            return bmp;
        }

        private Bitmap getCodeBmp(string code,int w,int h)
        {
            Bitmap bmp = null;
            try
            {
                //QRCodeEncoder coder = new QRCodeEncoder();
                //coder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE;
                //coder.QRCodeScale = 4;
                //coder.QRCodeVersion = 7;
                //coder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
                //bmp = coder.Encode(code);
                EncodingOptions opt = new EncodingOptions
                {
                    Width = w,
                    Height = h
                };
                BarcodeWriter writer = new BarcodeWriter();
                writer.Format = BarcodeFormat.ITF;
                writer.Options = opt;
                bmp = writer.Write(code);
            }
            catch (Exception e)
            {

            }
            return bmp;
        }
    }
}
