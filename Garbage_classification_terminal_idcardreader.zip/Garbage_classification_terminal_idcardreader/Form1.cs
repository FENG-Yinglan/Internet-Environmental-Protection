﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;


namespace idcard3
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        public static extern int SetWindowsHookEx(int idHook, HookProc hProc, IntPtr hMod, int dwThreadId);
        [DllImport("user32.dll")]
        public static extern int CallNextHookEx(int hHook, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")]
        public static extern bool UnhookWindowsHookEx(int hHook);
        [DllImport("kernel32.dll")]//获取模块句柄  
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        public struct KeyInfoStruct
        {
            public int vkCode;        //按键键码
            public int scanCode;
            public int flags;       //键盘是否按下的标志
            public int time;
            public int dwExtraInfo;
        }

        private const int WH_KEYBOARD_LL = 13;      //钩子类型 全局钩子
        private const int WM_KEYUP = 0x101;     //按键抬起
        private const int WM_KEYDOWN = 0x100;       //按键按下

        public delegate int HookProc(int nCode, IntPtr wParam, IntPtr lParam);
        bool bStopMsg = false;
        int hHook = 0;
        GCHandle gc;

        public int MethodHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                KeyInfoStruct inputInfo = (KeyInfoStruct)Marshal.PtrToStructure(lParam, typeof(KeyInfoStruct));
                if (wParam == (IntPtr)WM_KEYDOWN)
                {//如果按键按下
                    //tb_usb_cardno.Text += "-" + ((Keys)inputInfo.vkCode).ToString() + "-";
                    if(inputInfo.vkCode==13)
                    {
                        onIdCardReaded(mIdCode);
                        mIdCode = "";
                    }
                    else
                    {
                        mIdCode += (char)((Keys)inputInfo.vkCode);
                    }
                }
                if (bStopMsg)
                    return 1;
            }
            return CallNextHookEx(hHook, nCode, wParam, lParam);//继续传递消息
        }


        public void onIdCardReaded(string id)
        {
            MessageBox.Show(id);
        }

        private string mIdCode="";

        public Form1()
        {
            InitializeComponent();
            if (0 == hHook)
            {
            HookProc KeyCallBack = new HookProc(MethodHookProc);
            hHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyCallBack,
            GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName), 0);
            if (hHook == 0)
            {
                MessageBox.Show("设置Hook失败");
            }
            else
            { 
                gc = GCHandle.Alloc(KeyCallBack);   //保持活动 避免 回调过程 被垃圾回收
            }
        }
            bStopMsg = true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (UnhookWindowsHookEx(hHook))
            {
                hHook = 0;
                gc.Free();
            }
            else
            {
                MessageBox.Show("卸载失败");
            }
        }
    }
}



