﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minyCircle2
{
    class PacketGoods : ProductBase
    {
        public override List<Goods> getGoods()
        {
            List<Goods> rst = new List<Goods>();
            Goods g1 = new Goods();
            Goods g2 = new Goods();
            Goods g3 = new Goods();
            Goods g4 = new Goods();
            //设置属性
            g1.ImgPath = "goodsImg/u32.png";
            g1.Name = "可回收垃圾袋(绿色)";
            g1.MoneyCoast = 5.0;
            g1.ScoreCoast = 200;

            g2.ImgPath = "goodsImg/u34.png";
            g2.Name = "可回收垃圾袋(黑色)";
            g2.MoneyCoast = 5.0;
            g2.ScoreCoast = 200;

            g3.ImgPath = "goodsImg/u38.png";
            g3.Name = "可回收垃圾袋(紫色)";
            g3.MoneyCoast = 5.0;
            g3.ScoreCoast = 200;

            g4.ImgPath = "goodsImg/u36.png";
            g4.Name = "可回收垃圾袋(蓝色)";
            g4.MoneyCoast = 5.0;
            g4.ScoreCoast = 200;
            //设置结束
            rst.Add(g1);
            rst.Add(g2);
            rst.Add(g3);
            rst.Add(g4);
            return rst;
        }
    }
}
