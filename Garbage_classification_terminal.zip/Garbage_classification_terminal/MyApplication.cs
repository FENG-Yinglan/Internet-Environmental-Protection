﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minyCircle2
{
    class MyApplication
    {
        private static MyApplication mInstance = new MyApplication();

        public const string UrlRoot = "http://127.0.0.1:8080/";

        public const string terminalId = "009";

        private MyApplication() { }

        public static MyApplication getInstance()
        {
            return mInstance;
        }


        private User mUser;
        private MainForm mMainForm;

        public MainForm MainForm
        {
            set
            {
                mMainForm = value;
            }
            get
            {
                return mMainForm;
            }
        }

        public User User
        {
            set
            {
                mUser = value;
            }
            get
            {
                return mUser;
            }
        }
    }
}
