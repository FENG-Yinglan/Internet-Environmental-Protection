﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class OutGoods : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        private Goods mGoods;

        public OutGoods(Goods goods)
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_OUTGOODS;
            mMain.showForm();
            mMain.onPayOutHiden();
            mMain.hideAllButtom();
            fillControl(goods);
            mGoods = goods;
            label2.Text = "正在出货\n请稍后......";
            timer1.Start();
        }

        private void fillControl(Goods g)
        {
            if (!string.IsNullOrEmpty(g.ImgPath))
                pictureBox1.Image = new Bitmap(g.ImgPath);
            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
            label1.Text = lstr;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //跳转页面
            timer1.Stop();
            new OutGoodsOk(mGoods);
        }
    }
}
