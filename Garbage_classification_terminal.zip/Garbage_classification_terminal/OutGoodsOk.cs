﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class OutGoodsOk : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        public OutGoodsOk(Goods goods)
        {
            InitializeComponent();


            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_OUTGOODS_OK;
            mMain.showForm();
            fillControl(goods);

            label2.Text = "出货成功!\n请取走您的";
            timer1.Start();
        }


        private void fillControl(Goods g)
        {
            if (!string.IsNullOrEmpty(g.ImgPath))
                pictureBox1.Image = new Bitmap(g.ImgPath);
            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
            label1.Text = lstr;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            new MainSpace();
        }
    }
}
