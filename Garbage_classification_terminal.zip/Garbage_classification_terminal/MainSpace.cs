﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class MainSpace : Form
    {

        private MyApplication mApplication;

        private MainForm mMain;

        public MainSpace()
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_MAIN;
            mMain.showForm();
            mMain.showTime();

            if (mApplication.User != null)
            {
                mMain.showUserInfo(mApplication.User);
                mMain.addLogoutAndShow();
            }
            else
            {
                mMain.hideUserInfo();
                mMain.showButtom();
            }
            //mMain.hideAllButtom();
        }
    }
}
