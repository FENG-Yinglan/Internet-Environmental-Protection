﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class HelpLogin : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        public HelpLogin()
        {
            InitializeComponent();
            mApplication = MyApplication.getInstance();
            //mApplication.MainForm.realseForm();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_HELP_LOGIN;
            mMain.showForm();
            //mMain.hideAllButtom();
            mMain.showCancel();
        }
    }
}
