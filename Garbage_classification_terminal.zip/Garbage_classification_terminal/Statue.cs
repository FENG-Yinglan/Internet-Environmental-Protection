﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace minyCircle2
{
    public partial class Statue : Form
    {
        public const int LOGIN_OK = 0;
        public const int PRINT_OK = 1;
        public const int LOGIN_NO = 2;

        private MyApplication mApplication;

        private MainForm mMain;

        private int mStatue;

        private int mTimer = 3;
       
        private Statue()
        {
            InitializeComponent();
        }

        public Statue(int statue)
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_STATUES;
            mMain.showForm();
            mMain.hideAllButtom();

            mStatue = statue;
            switch (mStatue)
            {
                case LOGIN_OK:
                    label1.Text = "登录成功!";
                    break;
                case PRINT_OK:
                    label1.Text = "打印成功!";
                    break;
                case LOGIN_NO:
                    label1.Text = "登录失败，请重新登录";
                    break;
                default:
                    break;
            }
            timer2.Start();
            timer1.Start();
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            new MainSpace();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            new MainSpace();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            label3.Text = ""+ (--mTimer)+"秒后跳转至首页...";
        }
    }
}
