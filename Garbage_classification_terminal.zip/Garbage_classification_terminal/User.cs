﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace minyCircle2
{
    public class User
    {
        private string mName;

        private Bitmap mHead;

        private string mToken;

        private double mScore;

        public User()
        {
            mName = "张三";
            mHead =Properties.Resources.head;
        }

        public string Name
        {
            get { return mName; }
            set { mName = value; }
        }

        public double Score
        {
            get { return mScore; }
            set { mScore = value; }
        }

        public Bitmap HeadBmp
        {
            get { return mHead;}
            set { mHead = value; }
        }

        public string Token
        {
            get { return mToken; }
            set { mToken = value; }
        }
    }
}
