﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeScales.Http;
using CodeScales.Http.Methods;
using CodeScales.Http.Entity;
using CodeScales.Http.Common;
using LitJson;

namespace minyCircle2
{
    class NetOperationUtils
    {

        private const string INDEX_URL = "http://aliy.w3.luyouxia.net/tUser";

        public static User loginByPwd(string name,string pwd)
        {
            const string url = "/loginByUserName";
            string[] para = new string[4];
            para[0] = "name";
            para[1] = name;
            para[2] = "password";
            para[3] = pwd;
            string json = NetWork.getInstance().post(INDEX_URL+url,para);
            JsonData jd = JsonMapper.ToObject(json);
            int error = (int)jd["errorno"];
            if (error != 0)
                return null;
            User user = new User();
            JsonData data = jd["data"];
            user.Name = (string)data["nickname"];
            user.Token = (string)data["token"];
            user.Score = (double)data["score"];
            return user;
        }

        public static User loginByCard(string num)
        {
            const string url = "/loginByCard";
            string[] para = new string[2];
            para[0] = "cardNo";
            para[1] = num;
            string json = NetWork.getInstance().post(INDEX_URL + url, para);
            JsonData jd = JsonMapper.ToObject(json);
            int error = (int)jd["errorno"];
            if (error != 0)
                return null;
            User user = new User();
            JsonData data = jd["data"];
            user.Name = (string)data["nickname"];
            user.Token = (string)data["token"];
            user.Score = (double)data["score"];
            return user;
        }

        public static int uploadQrCode(string code)
        {
            const string url = "/qrUpload";
            string[] para = new string[2];
            para[0] = "qrCode";
            para[1] = code;
            string json = NetWork.getInstance().post(INDEX_URL + url, para);
            JsonData jd = JsonMapper.ToObject(json);
            int error = (int)jd["errorno"];
            if (error != 0)
                return -1;
            return 0;
        }

        public static User loginByQrCode(string code)
        {
            const string url = "/loginByQrCode";
            string[] para = new string[2];
            para[0] = "qrCode";
            para[1] = code;
            string json = NetWork.getInstance().post(INDEX_URL + url, para);
            JsonData jd = JsonMapper.ToObject(json);
            int error = (int)jd["errorno"];
            if (error != 0)
                return null;
            User user = new User();
            JsonData data = jd["data"];
            user.Name = (string)data["nickname"];
            user.Token = (string)data["token"];
            user.Score = (double)data["score"];
            return user;
        }

        public static int uploadLable(User user,string label,int type)
        {
            const string url = "/labelUpload";
            string[] para = new string[6];
            para[0] = "token";
            para[1] = user.Token;
            para[2] = "label";
            para[3] = label;
            para[4] = "type";
            para[5] = "" + type;
            string json = NetWork.getInstance().post(INDEX_URL + url, para);
            JsonData jd = JsonMapper.ToObject(json);
            int error = (int)jd["errorno"];
            if (error != 0)
                return -1;
            return 0;
        }

        public static int consume(User user,double cost,int type)
        {
            const string url = "/consumeByScore";
            string[] para = new string[6];
            para[0] = "token";
            para[1] = user.Token;
            para[2] = "cost";
            para[3] = ""+(cost);
            para[4] = "type";
            para[5] = "" + type;
            string json = NetWork.getInstance().post(INDEX_URL + url, para);
            JsonData jd = JsonMapper.ToObject(json);
            int error = (int)jd["errorno"];
            if (error != 0)
                return -1;
            return 0;
        }

        private class NetWork
        {
            private static NetWork mInstance = new NetWork();
            private HttpClient mCline = new HttpClient();
        
            private NetWork()
            {
                
            }
            public static NetWork getInstance()
            {
                return mInstance;
            }

            public string post(string url,string []paras)
            {
                HttpPost post = new HttpPost(new Uri(url));
                List<NameValuePair> para = new List<NameValuePair>();
                for (int i = 0; i <paras.Count();i=i+2)
                {
                    para.Add(new NameValuePair(paras[i], paras[i + 1]));
                }
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(para, Encoding.UTF8);
                post.Entity = entity;
                HttpResponse res = mCline.Execute(post);
                return EntityUtils.ToString(res.Entity);
            }

        }
    }
}
