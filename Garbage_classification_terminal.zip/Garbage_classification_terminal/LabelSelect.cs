﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class LabelSelect : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        private int[] mLabels;

        public LabelSelect()
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_LABLE_SELECT;
            mMain.showForm();
            //mMain.showCancel();
            mLabels = new int[4];
        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (mLabels[0] > 0)
                mLabels[0]--;
            if (labelCount() == 0)
                label18.BackColor = Color.FromArgb(102,102,102);
            label4.Text = ""+mLabels[0];
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (mLabels[1] > 0)
                mLabels[1]--;
            if (labelCount() == 0)
                label18.BackColor = Color.FromArgb(102, 102, 102);
            label8.Text = "" + mLabels[1];
        }

        private void label11_Click(object sender, EventArgs e)
        {
            if (mLabels[2] > 0)
                mLabels[2]--;
            if (labelCount() == 0)
                label18.BackColor = Color.FromArgb(102, 102, 102);
            label12.Text = "" + mLabels[2];
        }

        private void label15_Click(object sender, EventArgs e)
        {
            if (mLabels[3] > 0)
                mLabels[3]--;
            if (labelCount() == 0)
                label18.BackColor = Color.FromArgb(102, 102, 102);
            label16.Text = "" + mLabels[3];
        }

        private void label5_Click(object sender, EventArgs e)
        {
            mLabels[0]++;
            if (labelCount() != 0)
                label18.BackColor = Color.FromArgb(51, 153, 136);
            label4.Text = "" + mLabels[0];
        }

        private void label9_Click(object sender, EventArgs e)
        {
            mLabels[1]++;
            if (labelCount() != 0)
                label18.BackColor = Color.FromArgb(51, 153, 136);
            label8.Text = "" + mLabels[1];
        }

        private void label13_Click(object sender, EventArgs e)
        {
            mLabels[2]++;
            if (labelCount() != 0)
                label18.BackColor = Color.FromArgb(51, 153, 136);
            label12.Text = "" + mLabels[2];
        }

        private void label17_Click(object sender, EventArgs e)
        {
            mLabels[3]++;
            if (labelCount() != 0)
                label18.BackColor = Color.FromArgb(51, 153, 136);
            label16.Text = "" + mLabels[3];
        }

        private void label18_Click(object sender, EventArgs e)
        {
            if (mLabels[0] + mLabels[1] + mLabels[2] + mLabels[3] == 0)
                return;
            new LabelPrintting(mLabels);
        }

        private int labelCount()
        {
            int rst = 0;
            foreach (int i in mLabels)
                rst += i;
            return rst;
        }
    }
}
