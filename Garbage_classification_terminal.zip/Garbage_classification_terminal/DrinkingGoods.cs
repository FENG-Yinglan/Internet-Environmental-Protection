﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minyCircle2
{
    class DrinkingGoods : ProductBase
    {
        public override List<Goods> getGoods()
        {
            List<Goods> rst = new List<Goods>();
            Goods[] goods = new Goods[6];
            goods[0] = new Goods();
            goods[1] = new Goods();
            goods[2] = new Goods();
            goods[3] = new Goods();
            goods[4] = new Goods();
            goods[5] = new Goods();

            goods[0].ImgPath = "goodsImg/u14.png";
            goods[0].Name = "可口可乐 330ml";
            goods[0].MoneyCoast = 2.50;
            goods[0].ScoreCoast = 100;

            goods[1].ImgPath = "goodsImg/u16.png";
            goods[1].Name = "雪碧 330ml";
            goods[1].MoneyCoast = 2.50;
            goods[1].ScoreCoast = 100;

            goods[2].ImgPath = "goodsImg/u18.png";
            goods[2].Name = "农夫山泉 500ml";
            goods[2].MoneyCoast = 2.00;
            goods[2].ScoreCoast = 80;

            goods[3].ImgPath = "goodsImg/u22.png";
            goods[3].Name = "加多宝 310ml";
            goods[3].MoneyCoast = 4.00;
            goods[3].ScoreCoast = 160;

            goods[4].ImgPath = "goodsImg/u20.png";
            goods[4].Name = "雀巢咖啡 310ml";
            goods[4].MoneyCoast = 4.00;
            goods[4].ScoreCoast = 160;

            goods[5].ImgPath = "goodsImg/u24.png";
            goods[5].Name = "统一冰红茶 550ml";
            goods[5].MoneyCoast = 3.00;
            goods[5].ScoreCoast = 120;
            foreach(Goods g in goods)
            {
                rst.Add(g);
            }
            return rst;
        }
    }
}
