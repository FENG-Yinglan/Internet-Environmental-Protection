﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class LoginSelect : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        public LoginSelect()
        {
            InitializeComponent();
            mApplication = MyApplication.getInstance();
            //mApplication.MainForm.realseForm();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_LOGIN_SELECT;
            mMain.showForm();
            //mMain.hideAllButtom();
            mMain.showButtom();
        }

        private void label2_Click(object sender, EventArgs e)
        { 
            new LoginByCard();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            new LoginByQrCode();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            new LoginByPassword();
        }
    }
}
