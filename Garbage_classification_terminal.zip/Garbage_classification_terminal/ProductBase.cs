﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minyCircle2
{
    /**
    产品的基类
    */
    abstract class  ProductBase
    {
        public abstract List<Goods> getGoods();
    }
}
