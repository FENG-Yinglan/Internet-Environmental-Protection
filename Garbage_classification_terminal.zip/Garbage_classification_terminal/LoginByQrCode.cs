﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ZXing;
using ZXing.Common;
using ZXing.QrCode;


namespace minyCircle2
{
    public partial class LoginByQrCode : Form
    {
        private const string terminalId = "GD001";

        private MyApplication mApplication;

        private MainForm mMain;

        private int mRequstNum = 0;

        private Object mLock = new Object();

        //二维码有机器ID+时间组成
        private string mCode;
        public LoginByQrCode()
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_LOGIN_BY_QRCAODE;
            mMain.showForm();
            mMain.showCancel();

            mCode = terminalId+ DateTime.Now.Ticks;
            pictureBox1.Image = getCodeBmp(mCode);
            uploadQrCode(mCode);
            timer1.Start();
        }

        //上传生成的二维码
        public void uploadQrCode(string code)
        {
            NetOperationUtils.uploadQrCode(code);
        }

        private Bitmap getCodeBmp(string code)
        {
            Bitmap bmp = null;
            try
            {
                EncodingOptions opt = new QrCodeEncodingOptions
                {
                    DisableECI = true,
                    CharacterSet = "UTF-8",
                    Width = pictureBox1.Width,
                    Height = pictureBox1.Height
                };
                BarcodeWriter writer = new BarcodeWriter();
                writer.Format = BarcodeFormat.QR_CODE;
                writer.Options = opt;
                bmp = writer.Write(code);
            }
            catch(Exception e)
            {

            }
            return bmp;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lock(mLock)
            {
                ++mRequstNum;
                if (mRequstNum > 12)
                {
                    timer1.Stop();
                    mApplication.MainForm.Form = new Statue(Statue.LOGIN_NO);
                }
                User user = NetOperationUtils.loginByQrCode(mCode);
                if (user == null)
                    return;
                mApplication.User = user;
                timer1.Stop();
                mApplication.MainForm.Form = new Statue(Statue.LOGIN_OK);
            }
        }
    }
}
