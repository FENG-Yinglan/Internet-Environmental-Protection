﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vlc.net;

namespace minyCircle2
{
    public partial class Add : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        private VlcPlayer vlc_player_;
        //private bool is_playinig_;

        //string path = "";

        double videoLen = 0;

        public Add()
        {
            InitializeComponent();
            mApplication = MyApplication.getInstance();
            //mApplication.MainForm.realseForm();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_ADD;
            mMain.showForm();
            mMain.hideAllButtom();
            mMain.hideTime();
            //设置用户退出
            mApplication.User = null;
            mMain.hideUserInfo();
            vlc_init(false);
            timer1.Start();
            vlc_player_.PlayFile("c:\\a.mkv");
            videoLen = vlc_player_.Duration();
        }

        public void vlc_init(bool is_record)
        {
            string pluginPath = System.Environment.CurrentDirectory + "\\plugins\\";
            vlc_player_ = new VlcPlayer(pluginPath, is_record);
            IntPtr render_wnd = this.pictureBox1.Handle; //this.panel1.Handle;
            vlc_player_.SetRenderWindow((int)render_wnd);

            //tbVideoTime.Text = "00:00:00/00:00:00";

            //is_playinig_ = false;
        }

        private void Add_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (vlc_player_ != null)
            {
                //释放
                vlc_player_.Stop();
                vlc_player_.Vlc_release();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            vlc_player_.SetPlayTime(0);
        }
    }
}
