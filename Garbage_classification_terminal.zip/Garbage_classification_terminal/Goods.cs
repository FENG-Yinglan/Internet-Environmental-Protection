﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minyCircle2
{
    public class Goods
    {
        private string mImgPath;
        private string mName;
        private double mMoneyCoast;
        private double mScoreCoast;

        public string ImgPath
        {
            get
            {
                return mImgPath;
            }

            set
            {
                mImgPath = value;
            }
        }

        public string Name
        {
            get
            {
                return mName;
            }

            set
            {
                mName = value;
            }
        }

        public double MoneyCoast
        {
            get
            {
                return mMoneyCoast;
            }

            set
            {
                mMoneyCoast = value;
            }
        }

        public double ScoreCoast
        {
            get
            {
                return mScoreCoast;
            }

            set
            {
                mScoreCoast = value;
            }
        }
    }

}
