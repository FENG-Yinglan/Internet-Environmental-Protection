﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class HelpSelect : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        public HelpSelect()
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_HELP_SELECT;
            mMain.showForm();
            mMain.showButtom();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            new HelpLogin();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            //无法打印
            new HelpLable();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            //购买商品为出货
            new HelpGoods();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            //无法放入纸币
            new HelpMoney();
        }
    }
}
