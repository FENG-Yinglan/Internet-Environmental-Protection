﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ZXing;
using ZXing.Common;
using ZXing.QrCode;

namespace minyCircle2
{
    public partial class LabelPrintting : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        private int []mLaels;

        private string[] mCodes;
        private int[] mTypes;


        private const string mLableTitle = "垃圾回收系统";

        private int mCurrentPage = 0;

        //以下成员为了构建mcode使用
        //mcode = 机器id+ 时间  +随机数+ 类别
        //类别 2可回收 4不可回收 6电子 8玻璃

        public LabelPrintting(int []labels)
        {
            InitializeComponent();
            mLaels = labels;

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_LABLE_SELECT;
            mMain.showForm();
            mMain.hideAllButtom();

            //完成对mCodes的构建
            List<Int32> list = new List<int>(); 
            for(int i = 0; i < labels.Length; ++i)
            {
                for (int j = 0; j < labels[i]; ++j)
                    list.Add(i);
            }
            mCodes = new string[list.Count()];
            mTypes = new int[list.Count()];
            Random rm = new Random();
            for(int i = 0; i < mCodes.Length;++i)
            {
                DateTime now = DateTime.Now;
                mCodes[i] = MyApplication.terminalId + (DateTime.Now.Ticks % 10000).ToString().PadLeft(4, '0') + (rm.Next() % 1000).ToString().PadLeft(3, '0') + (list[i]+1).ToString().PadLeft(2,'0');
                mCodes[i] = MyApplication.terminalId + now.Year.ToString().PadLeft(4, '0') + now.Month.ToString().PadLeft(2, '0') + now.Day.ToString().PadLeft(2, '0')
                    + (++flag).ToString().PadLeft(4, '0') + (list[i] + 1).ToString();
                //mCodes[i] = "0000000000000000";
                mTypes[i] = list[i];
            }

            printDocument1.Print();

            new Statue(Statue.PRINT_OK);
        }

        private void LabelPrintting_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("xxx");
            //printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int w = e.PageBounds.Width;
            int h = e.PageBounds.Height;
            //MessageBox.Show("w:"+w+"\nh:"+h);
            if (mCurrentPage < mCodes.Length -1)
                e.HasMorePages = true;
            else
                e.HasMorePages = false;
            Graphics g = e.Graphics;
            Bitmap bmp = getPrintContext(mCurrentPage,w,h);
            g.DrawImage(bmp, 0, -5);
            mCurrentPage++;
        }

        private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            mCurrentPage = 0;
        }

        static int flag = 0;

        private Bitmap getPrintContext(int index,int w,int h)
        {
            //Bitmap bmp = new Bitmap(w,h);
            //Graphics g = Graphics.FromImage(bmp);

            //StringFormat sf = new StringFormat();
            //sf.Alignment = StringAlignment.Center;
            //sf.LineAlignment = StringAlignment.Center;
            //g.DrawString(mLableTitle, this.Font, Brushes.Black, new Rectangle(0, 0, w, (int)(h * 0.25)), sf);
            //int barH = (int)(h * 0.5);
            //g.DrawImage(getBarCode(mCodes[index], w, barH), -5, (int)(h * 0.25));
            //NetOperationUtils.uploadLable(mApplication.User, mCodes[index], mTypes[index]);
            ////Bitmap bmp2 = getBarCode(mCodes[index], w, barH);

            Bitmap bmp = new Bitmap(w, h);
            Graphics g = Graphics.FromImage(bmp);
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            g.DrawString(mLableTitle, new Font(this.Font, FontStyle.Bold), Brushes.Black, new Rectangle(0, 0, w, (int)(h * 0.125)), sf);
            g.DrawImage(getBarCode2(mCodes[index], w, (int)(h * 0.35)), 0, (int)(h * 0.125));
            NetOperationUtils.uploadLable(mApplication.User, mCodes[index], mTypes[index]);
            string stype = "";
            string stypecode = "";
            switch (mTypes[index])
            {
                case 0:
                    stype = "可回收垃圾";
                    stypecode = "00024292";
                    break;
                case 1:
                    stype = "厨余垃圾";
                    stypecode = "00024293";
                    break;
                case 2:
                    stype = "其他垃圾";
                    stypecode = "00024294";
                    break;
                case 3:
                    stype = "有害垃圾";
                    stypecode = "00024295";
                    break;
                default:
                    break;
            }
            g.DrawString(stype, this.Font, Brushes.Black, new Rectangle(0, (int)(0.465 * h), w, (int)(h * 0.125)), sf);
            g.DrawImage(getBarCode(stypecode, w, (int)(h * 0.4)), 0, (int)(h * 0.57));
            return bmp;

            //string stype = "";
            //switch (mTypes[index])
            //{
            //    case 0:
            //        stype = "可回收垃圾";
            //        break;
            //    case 1:
            //        stype = "不可回收垃圾";
            //        break;
            //    case 2:
            //        stype = "电池电子产品";
            //        break;
            //    case 3:
            //        stype = "玻璃";
            //        break;
            //    default:
            //        break;
            //}
            //g.DrawString(stype, this.Font, Brushes.Black, new Rectangle(0, (int)(0.75*h), w, (int)(h * 0.25)), sf);
            //return bmp;
        }

        private Bitmap getBarCode(string code,int w,int h)
        {
            Bitmap bmp = null;
            try
            {
                EncodingOptions opt = new EncodingOptions
                {
                    Width = w,
                    Height = h
                };
                BarcodeWriter writer = new BarcodeWriter();
                writer.Format = BarcodeFormat.CODE_128;
                writer.Options = opt;
                bmp = writer.Write(code);
            }
            catch (Exception e)
            {
            }
            return bmp;
        }


        private Bitmap getBarCode2(string code, int w, int h)
        {
            Bitmap bmp = null;
            try
            {
                EncodingOptions opt = new EncodingOptions
                {
                    Width = w,
                    Height = h
                };
                BarcodeWriter writer = new BarcodeWriter();
                writer.Format = BarcodeFormat.ITF;
                writer.Options = opt;
                bmp = writer.Write(code);
            }
            catch (Exception e)
            {
            }
            return bmp;
        }
    }
}
