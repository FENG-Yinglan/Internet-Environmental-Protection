﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace minyCircle2
{
    public partial class MainForm : Form
    {
        public const int FORM_MAIN = 0;
        public const int FORM_LOGIN_SELECT = 1;
        public const int FORM_LOGIN_BY_CARD = 2;
        public const int FORM_LOGIN_BY_QRCAODE = 3;
        public const int FORM_LOGIN_BY_PASSWORD = 4;
        public const int FORM_LABLE_SELECT = 5;
        public const int FORM_LABLE_PRINTTING = 6;
        public const int FORM_STATUES = 7;
        public const int FORM_HELP_SELECT = 8;
        public const int FORM_HELP_LOGIN = 9;
        public const int FORM_GOODS_SELECT = 10;
        public const int FORM_PAYOUT = 11;
        public const int FORM_OUTGOODS = 12;
        public const int FORM_OUTGOODS_OK = 13;
        public const int FORM_HELP_LABLE = 14;
        public const int FORM_HELP_GOODS = 15;
        public const int FORM_HELP_MONEY = 16;
        public const int FORM_ADD = 17;

        private int mFormType;
        private Form mForm;

        private MyApplication mApplication;

        private volatile int mNowTimes = 60;

        //键盘钩子开始
        public delegate int HookProc(int nCode, IntPtr wParam, IntPtr lParam);
        //定义钩子句柄
        public static int hHook = 0;
        //定义钩子类型
        public const int WH_MOUSE_LL = 14;
        public HookProc MyProcedure;
        //安装钩子
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern int SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hInstance, int threadId);
        //卸载钩子
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern bool UnhookWindowsHookEx(int idHook);
        //调用下一个钩子
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern int CallNextHookEx(int idHook, int nCode, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        public class POINT
        {
            public int x;
            public int y;
        }

        [StructLayout(LayoutKind.Sequential)]
        public class MouseHookStruct
        {
            public POINT pt;
            public int hwnd;
            public int wHitTestCode;
            public int dwExtraInfo;
        }
        //键盘钩子结束

        public int FormType
        {
            set
            {
                mFormType = value;
            }
            get
            {
                return mFormType;
            }
        }

        public Form Form
        {
            set
            {
                mForm = value;
            }
            get
            {
                return mForm;
            }
        }

        public MainForm()
        {
            InitializeComponent();
            mApplication =  MyApplication.getInstance();
            if (mApplication.MainForm == null)
                mApplication.MainForm = this;
            if (mApplication.User != null)
                showUserInfo(mApplication.User);
            else
                hideUserInfo();
            showButtom();
            new MainSpace();
            //this.WindowState = FormWindowState.Maximized;
            panel2.Visible = false;
            //timer1.Start();
            timer2.Start();
            //钩子安装
            MyProcedure = new HookProc(this.MouseHookProc);
            //这里挂节钩子
            hHook = SetWindowsHookEx(WH_MOUSE_LL, MyProcedure, Process.GetCurrentProcess().MainModule.BaseAddress, 0);
            if (hHook == 0)
            {
                MessageBox.Show("SetWindowsHookEx Failed");
                return;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            //标签打印
            if (mFormType == FORM_LABLE_SELECT)
                return;
            realseForm();
            if (mApplication.User == null)
            {
               new LoginSelect();
               
            }
            else
            {
                mForm = new LabelSelect();
                mFormType = FORM_LABLE_SELECT;
            }
            showForm();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            //商品购买
            if (FormType != FORM_GOODS_SELECT)
                new GoodsSelect();

        }

        private void label5_Click(object sender, EventArgs e)
        {
            //帮助
            if (FormType != FORM_HELP_SELECT)
                new HelpSelect();
        }

        
        private void label2_Click_1(object sender, EventArgs e)
        {
            //退出按钮
            if(mFormType == FORM_LOGIN_BY_PASSWORD || mFormType == FORM_LOGIN_BY_CARD || mFormType == FORM_LOGIN_BY_QRCAODE)   
                new LoginSelect();
            if (mFormType == FORM_HELP_LOGIN || mFormType == FORM_HELP_LABLE || mFormType == FORM_HELP_MONEY || mFormType == FORM_HELP_GOODS)
                new HelpSelect();
        }

        public void showUserInfo(User user)
        {
            userName.Text = user.Name;
            userHead.Image = user.HeadBmp;
            userName.Show();
            userHead.Show();
        }

        public void hideUserInfo()
        {
            userName.Hide();
            userHead.Hide();
        }

        public void showCancel()
        {
            label2.Show();
            label3.Hide();
            label4.Hide();
            label5.Hide();
        }

        public void hideAllButtom()
        {
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            label6.Hide();
        }

        public void showButtom()
        {
            label6.Hide();
            label2.Hide();
            //这里也要调整大小
            label3.Location = new Point(100,16);
            label4.Location = new Point(400, 16);
            label5.Location = new Point(700, 16);
            label3.Show();
            label4.Show();
            label5.Show();
        }

        public void realseForm()
        {
            if(Form!=null)
            {
                Form.Close();
                Form = null;
            }
        }

        public void showForm()
        {
            mForm.TopLevel = false;
            panelMain.Controls.Add(mForm);
            mForm.Show();
        }

        public void addLogoutAndShow()
        {
            //这里要调整底部控件的大小
            
            label2.Hide();
            //这里也要调整大小
            label6.Location = new Point(30,16);
            label3.Location = new Point(270, 16);
            label4.Location = new Point(510, 16);
            label5.Location = new Point(760, 16);
            label3.Show();
            label4.Show();
            label5.Show();
            label6.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            //退出登录
            mApplication.User = null;
            new MainSpace();
        }

        public void onPayOutShow()
        {
            panel3.Visible = false;
            panel2.Visible = true;
        }

        public void onPayOutHiden()
        {
            panel3.Visible = true;
            panel2.Visible = false;
        }

        private void changePayWay(int way)
        {
            if (way == PayOut.PAY_BY_CASH)
            {
                label8.BackColor = Color.FromArgb(188, 188, 188);
                label9.BackColor = Color.FromArgb(67,67,67);
                label10.BackColor = Color.FromArgb(67, 67, 67);
            }
            if (way == PayOut.PAY_BY_SCORY)
            {
                label8.BackColor = Color.FromArgb(67, 67, 67);
                label9.BackColor = Color.FromArgb(188, 188, 188);
                label10.BackColor = Color.FromArgb(67, 67, 67);
            }
            if (way == PayOut.PAY_BY_3PARTY)
            {
                label8.BackColor = Color.FromArgb(67, 67, 67);
                label9.BackColor = Color.FromArgb(67, 67, 67);
                label10.BackColor = Color.FromArgb(188, 188, 188);
            }
        }


        public void hideTime()
        {
            label11.Visible = false;
        }

        public void showTime()
        {
            label11.Visible = true;
        }

        public void hideAllButton()
        {
            panel2.Visible = false;
            panel3.Visible = false;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            new GoodsSelect();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            PayOut.payOut.changePayOutWay(PayOut.PAY_BY_CASH);
            changePayWay(PayOut.PAY_BY_CASH);
        }

        private void label9_Click(object sender, EventArgs e)
        {
            PayOut.payOut.changePayOutWay(PayOut.PAY_BY_SCORY);
            changePayWay(PayOut.PAY_BY_SCORY);
        }

        private void label10_Click(object sender, EventArgs e)
        {
            PayOut.payOut.changePayOutWay(PayOut.PAY_BY_3PARTY);
            changePayWay(PayOut.PAY_BY_3PARTY);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if(mNowTimes>0)
                label11.Text = "" + mNowTimes--;
            if(mNowTimes==0)
            {
                if (mFormType != FORM_ADD)
                    new Add();
            }
        }
        

        //钩子处理
        public int MouseHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {

            MouseHookStruct MyMouseHookStruct = (MouseHookStruct)Marshal.PtrToStructure(lParam, typeof(MouseHookStruct));
            if ((int)wParam >= 513 && (int)wParam <= 520)
            {
                mNowTimes = 60;
                if (mFormType == FORM_ADD)
                    new MainSpace();
            }
            return CallNextHookEx(hHook, nCode, wParam, lParam);

        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //卸载钩子
            bool ret = UnhookWindowsHookEx(hHook);
            if (ret == false)
            {
                MessageBox.Show("UnhookWindowsHookEx Failed");
                return;
            }
            hHook = 0;
        }
    }
}
