﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace minyCircle2
{
    public partial class LoginByPassword : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        private const string HELLO_USER = "请输入账号";
        private const string HELLO_PWD = "请输入密码";

        public LoginByPassword()
        {
            InitializeComponent();
            mApplication = MyApplication.getInstance();
            label4.Hide();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_LOGIN_BY_PASSWORD;
            mMain.showForm();
            mMain.showCancel();


            textBox1.Text = HELLO_USER;
            textBox2.Text = HELLO_PWD;
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            //登录
            string name = textBox1.Text;
            string password = textBox2.Text;
            if ("".Equals(name) || "".Equals(password))
            {
                label4.Show();
                Thread thread = new Thread(new ThreadStart(startOnUIThread));
                thread.IsBackground = true;
                thread.Start();
                return;
            }
            if(isOk(name,password))
            {
                //mApplication.User = new User();
                mApplication.MainForm.Form = new Statue(Statue.LOGIN_OK);
            }
            else
            {
                mApplication.MainForm.Form = new Statue(Statue.LOGIN_NO);
            }
        }

        public bool isOk(string name,string password)
        {
            //MyApplication.getInstance().User = new User();
            //return true;
            User user = NetOperationUtils.loginByPwd(name, password);
            if (user == null)
                return false;
            MyApplication.getInstance().User = user;
            return true;
        }

       private void startOnUIThread()
        {
            if (this.InvokeRequired)
                BeginInvoke(new EventHandler(startOnWorkThread), null)
;        }

        private void startOnWorkThread(object sender,EventArgs e)
        {
            Thread.Sleep(1000);
            label4.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if(textBox1.Text.Equals(HELLO_USER))
                textBox1.Text = "";
            ShowInputPanel();
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text.Equals(HELLO_PWD))
            {
                textBox2.Text = "";
                textBox2.PasswordChar = '*';
            }
            ShowInputPanel();
        }

        //屏幕键盘
        private const Int32 WM_SYSCOMMAND = 274;
        private const UInt32 SC_CLOSE = 61536;
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern bool PostMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern bool PostMessage(IntPtr hWnd, int Msg, uint wParam, uint lParam);
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int RegisterWindowMessage(string lpString);

        public static int ShowInputPanel()
        {
            try
            {
                dynamic file = "C:\\Program Files\\Common Files\\microsoft shared\\ink\\TabTip.exe";
                if (!System.IO.File.Exists(file))
                    return -1;
                Process.Start(file);
                return 0;
            }
            catch (Exception)
            {
                return 255;
            }
        }

        public static void HideInputPanel()
        {
            IntPtr TouchhWnd = new IntPtr(0);
            TouchhWnd = FindWindow("IPTip_Main_Window", null);
            if (TouchhWnd == IntPtr.Zero)
                return;
            PostMessage(TouchhWnd, WM_SYSCOMMAND, SC_CLOSE, 0);
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            HideInputPanel();
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            HideInputPanel();
        }
    }
}
