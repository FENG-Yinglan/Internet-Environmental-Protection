﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class PayOut : Form
    {
        public const int PAY_BY_CASH = 0;
        public const int PAY_BY_SCORY = 1;
        public const int PAY_BY_3PARTY = 2;

        private int mPayWay = -2;

        private MyApplication mApplication;

        private MainForm mMain;

        private User mUser;

        private Goods mGoods;

        public static PayOut payOut;

        private PayOut()
        {
            InitializeComponent();
        }

        public PayOut(Goods goods)
        {
            InitializeComponent();

            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_PAYOUT;
            mMain.showForm();
            mMain.onPayOutShow();
            mUser = mApplication.User;

            int way = -1;
            if (mUser != null)
                way = PAY_BY_SCORY;
            else
                way = PAY_BY_CASH;
            mGoods = goods;
            fillControl(goods, way);

            payOut = this;
        }

        private  void fillControl(Goods g,int way)
        {
            if (!string.IsNullOrEmpty(g.ImgPath))
                pictureBox1.Image = new Bitmap(g.ImgPath);
            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
            label1.Text = lstr;
            changePayOutWay(way);
        }

        //panel2现金
        //panel4积分
        //panel5第三方
        public void changePayOutWay(int way)
        {
            if (way == mPayWay)
                return;
            switch(way)
            {
                case PAY_BY_CASH:
                    panel2.Visible = true;
                    panel4.Visible = false;
                    panel5.Visible = false;
                    break;
                case PAY_BY_SCORY:
                    panel2.Visible = false;
                    panel4.Visible = true;
                    panel5.Visible = false;
                    updateUserInfo();
                    break;
                case PAY_BY_3PARTY:
                    panel2.Visible = false;
                    panel4.Visible = false;
                    panel5.Visible = true;
                    break;
                default:
                    break;
            }
            mPayWay = way;
            this.Refresh();
        }

        private void updateUserInfo()
        {
            User user = mApplication.User;
            if (user == null)
            {
                label3.Text = "游客您好，请先登录";
                label4.Text = "当前积分:0" ;
                label5.Text = "所需积分:" + mGoods.ScoreCoast;
                label6.BackColor = Color.Gray;
                return; 
            }
            label3.Text = "你好," + user.Name+"!";
            label4.Text = "当前积分:" + user.Score;
            label5.Text = "所需积分:" + mGoods.ScoreCoast;
            if (user.Score < mGoods.ScoreCoast)
                label6.BackColor = Color.Gray;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (mApplication.User.Score < mGoods.ScoreCoast)
                return;
            new OutGoods(mGoods);
            User user = mApplication.User;
            if (user == null)
                return;
            while(true)
            {
                if(0 == NetOperationUtils.consume(user,mGoods.ScoreCoast,1))
                {
                    break;
                }
            }
            user.Score -= mGoods.ScoreCoast;
            new OutGoods(mGoods);
        }
    }
}
