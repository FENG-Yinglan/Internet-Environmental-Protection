﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class GoodsSelect : Form
    {
        private MyApplication mApplication;
        private MainForm mMain;

        private int mPageNum = 0;

        List<Goods> mPackets;
        List<Goods> mDrinkings;

        public GoodsSelect()
        {
            InitializeComponent();
            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_GOODS_SELECT;
            mMain.showForm();
            mMain.onPayOutHiden();
            //mMain.hideAllButtom();
            //mMain.showCancel();

            fillControl();
            panel3.Visible = false;
            panel10.Visible = true;
        }

        private void fillControl()
        {
            //填充控件
            ProductBase product = new PacketGoods();
            //填充垃圾袋
            mPackets = product.getGoods();
            for(int i = 0; i < mPackets.Count(); ++i)
            {
                Goods g = mPackets[i];
                switch (i)
                {
                    case 0:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox12.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast +"\n"+ "积分:" + g.ScoreCoast;
                            label16.Text = lstr;
                            break;
                        }
                    case 1:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox10.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label14.Text = lstr;
                            break;
                        }
                    case 2:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox8.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label12.Text = lstr;
                            break;
                        }
                    case 3:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox11.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label15.Text = lstr;
                            break;
                        }
                    default:
                        break;
                }
            }
            //填充饮料
            product = new DrinkingGoods();
            mDrinkings = product.getGoods();
            for (int i = 0; i < mDrinkings.Count(); ++i)
            {
                Goods g = mDrinkings[i];
                switch (i)
                {
                    case 0:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox1.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label5.Text = lstr;
                            break;
                        }
                    case 1:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox2.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label6.Text = lstr;
                            break;
                        }
                    case 2:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox3.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label7.Text = lstr;
                            break;
                        }
                    case 3:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox6.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label10.Text = lstr;
                            break;
                        }
                    case 4:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox5.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label9.Text = lstr;
                            break;
                        }
                    case 5:
                        {
                            if (!string.IsNullOrEmpty(g.ImgPath))
                                pictureBox4.Image = new Bitmap(g.ImgPath);
                            string lstr = g.Name + "\n" + "￥" + g.MoneyCoast + "\n" + "积分:" + g.ScoreCoast;
                            label8.Text = lstr;
                            break;
                        }
                    default:
                        break;
                }
            }
        }



        private void label1_Click(object sender, EventArgs e)
        {
            if (mPageNum != 0)
            {
                mPageNum = 0;
                //换页
                Color c =  label1.BackColor;
                label1.BackColor = label2.BackColor;
                label2.BackColor = c;
                panel3.Visible = false;
                panel10.Visible = true;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (mPageNum != 1)
            {
                mPageNum = 1;
                //换页
                Color c = label1.BackColor;
                label1.BackColor = label2.BackColor;
                label2.BackColor = c;
                panel3.Visible = true;
                panel10.Visible = false;
            }
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            //绿色
            goToPayOut(goodsSelect(0));
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            //黑色
            goToPayOut(goodsSelect(1));
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            //紫色
            goToPayOut(goodsSelect(2));
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            //蓝色
            goToPayOut(goodsSelect(3));
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            goToPayOut(goodsSelect(10+0));
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            goToPayOut(goodsSelect(10 + 1));
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            goToPayOut(goodsSelect(10 + 2));
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            goToPayOut(goodsSelect(10 + 3));
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            goToPayOut(goodsSelect(10 + 4));
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            goToPayOut(goodsSelect(10 + 5));
        }

        private Goods goodsSelect(int i)
        {
            if (i < 10)
                return mPackets[i];
            else
                return mDrinkings[i - 10];
        }

        private void goToPayOut(Goods goods)
        {
            new PayOut(goods);
        }
    }
}
