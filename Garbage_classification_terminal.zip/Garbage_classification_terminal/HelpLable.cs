﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minyCircle2
{
    public partial class HelpLable : Form
    {
        private MyApplication mApplication;

        private MainForm mMain;

        public HelpLable()
        {
            InitializeComponent();
            mApplication = MyApplication.getInstance();
            mMain = mApplication.MainForm;
            mMain.realseForm();
            mMain.Form = this;
            mMain.FormType = MainForm.FORM_HELP_LABLE;
            mMain.showForm();
            //mMain.hideAllButtom();
            mMain.showCancel();
        }
    }
}
