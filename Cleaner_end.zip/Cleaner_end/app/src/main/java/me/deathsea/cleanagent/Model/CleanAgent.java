package me.deathsea.cleanagent.Model;



import me.deathsea.cleanagent.UserDataHelper;

/**
 * Created by deathsea on 2016/7/19.
 */
public class CleanAgent {
    private String username;
    private String token;
    private String cleanerName;
    private String cleanerHeadImg;
    private String cleanerNum;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCleanerName() {
        return cleanerName;
    }

    public void setCleanerName(String cleanerName) {
        this.cleanerName = cleanerName;
    }

    public String getCleanerHeadImg() {
        return cleanerHeadImg;
    }

    public void setCleanerHeadImg(String cleanerHeadImg) {
        this.cleanerHeadImg = cleanerHeadImg;
    }

    public String getCleanerNum() {
        return cleanerNum;
    }

    public void setCleanerNum(String cleanerNum) {
        this.cleanerNum = cleanerNum;
    }
}
