package me.deathsea.cleanagent;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class WorktimeActivity extends AppCompatActivity {

    private TextView todayTextView;
    private TextView workTimeTextView;
    private TextView hadWorkTimeTextView;
    private Button signOutButton;
    private ProgressDialog LogoutProgress;

    private String TESTWORKTIME = "7:30";
    private String TESTHADWORKTIME = "6H";

    private String Token = "";
    private String LOGOUTURL = "http://104.223.59.101:9999/cleanlogout";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worktime);

        todayTextView = (TextView)findViewById(R.id.todayTextView);
        workTimeTextView = (TextView)findViewById(R.id.workTimeTextView);
        hadWorkTimeTextView = (TextView)findViewById(R.id.hadWorkTimeTextView);
        signOutButton = (Button)findViewById(R.id.signoutButton);
        LogoutProgress = new ProgressDialog(this);

        Calendar myCalendar = Calendar.getInstance(Locale.CHINA);
        Date myDate = new Date();
        myCalendar.setTime(myDate);

        int year = myCalendar.get(Calendar.YEAR);
        int month = myCalendar.get(Calendar.MONTH);
        int day = myCalendar.get(Calendar.DAY_OF_MONTH);
        todayTextView.setText(String.format("%04d-%02d-%02d",year,month+1,day));

        workTimeTextView.setText(TESTWORKTIME);
        hadWorkTimeTextView.setText(TESTHADWORKTIME);

        signOutButton.setOnClickListener(new signOutButtonClick());
    }

    private class signOutButtonClick implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent i = new Intent(WorktimeActivity.this,LoginActivity.class);
            startActivity(i);
        }
    }

    private class checkToken extends AsyncTask<Void, Void, Integer> {
        @Override
        protected void onPreExecute() {
            LogoutProgress.show();
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            String Data = String.format("token=%s",
                    Token);
            HttpURLConnection htc = null;
            try {
                URL loginurl = new URL(LOGOUTURL);
                htc = (HttpURLConnection) loginurl.openConnection();
                htc.setRequestMethod("POST");
                htc.setDoOutput(true);
                OutputStreamWriter ops = new OutputStreamWriter(htc.getOutputStream());
                ops.write(Data);
                ops.flush();
                htc.connect();
                BufferedReader ist = new BufferedReader(
                        new InputStreamReader(
                                htc.getInputStream()));
                String Line;
                String JsonResult = "";
                while ((Line = ist.readLine()) != null) {
                    JsonResult = JsonResult.concat(Line);
                }
                ist.close();
                htc.disconnect();

                try {
                    JSONObject resultdata = new JSONObject(JsonResult);
                    int error = resultdata.getInt("errorno");
                    String errmsg = resultdata.getString("errmsg");
                    Log.e("LoginJsonReturnErrorMSG", errmsg);
                    //Log.i("------json error num",String.format("%s",error));
                    if (error != 0) {
                        return error;
                    } else {
                        return 111;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return -1;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            String ErrMsg = "Logout Success";
            switch (integer) {
                case 512://out date
                    ErrMsg = "Token out of date,please relogin";
                    break;
                case 256://token error
                    ErrMsg = "Token invalid ,please relogin";
                    break;
                case 111://token error
                    ErrMsg = "Token invalid ,please relogin";
                    break;
                case -1://network error
                    ErrMsg = "NetWork Error";
                    break;
                case 0:
                    LogoutProgress.dismiss();
                    return;
                default:
                    ErrMsg = "Unknow Error";

            }
            LogoutProgress.dismiss();
            Toast.makeText(WorktimeActivity.this.getApplicationContext(), ErrMsg, Toast.LENGTH_LONG).show();
//            LogoutProgress();
        }

    }
}
