package me.deathsea.cleanagent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import me.deathsea.cleanagent.UserDataHelper;
import me.deathsea.cleanagent.Model.CleanAgent;
/**
 * Created by deathsea on 2016/7/18.
 */
public class UserDataOps {
    private UserDataHelper UDH;
    public UserDataOps(Context context){
        UDH = new UserDataHelper(context);
    }
    public CleanAgent HasData()
    {
        SQLiteDatabase db = UDH.getReadableDatabase();
        String[] Selection = new String[]{"token","username","cleanerName","cleanerNum","cleanerHeadImg"};
        Cursor SQL = db.query(false,"user",Selection,"",null,null,null,null,"1");
        if (SQL.moveToFirst()){
            CleanAgent returnData = new CleanAgent();
            returnData.setToken(SQL.getString(0));
            returnData.setUsername(SQL.getString(1));
            returnData.setCleanerName(SQL.getString(2));
            returnData.setCleanerNum(SQL.getString(3));
            returnData.setCleanerHeadImg(SQL.getString(4));
            SQL.close();
            return returnData;
        }
        SQL.close();
        return null;
    }
    public boolean HasToken(String username)
    {
        boolean Has = false;
        SQLiteDatabase db = UDH.getReadableDatabase();
        String[] Selection = new String[]{"count(0)"};
        Cursor SQL = db.query(false,"user",Selection,"username=?",new String[]{username},null,null,null,"1");
        if (SQL.moveToFirst()){
            if(SQL.getInt(0) >= 1){
                Has = true;
            }
            else{Has = false;}
        }
        SQL.close();
        return Has;
    }

    public long Insert(CleanAgent insert){
        String targetTable = "user";
//        String nullColumnHack = null;
        ContentValues insertContent = new ContentValues();
        insertContent.put("token",insert.getToken());
        insertContent.put("username",insert.getUsername());
        insertContent.put("cleanerName",insert.getCleanerName());
        insertContent.put("cleanerNum",insert.getCleanerNum());
        insertContent.put("cleanerHeadImg",insert.getCleanerHeadImg());
        SQLiteDatabase db = UDH.getWritableDatabase();
        long co = db.insert(targetTable,null,insertContent);
        db.close();
        return co;//-1 when error
    }

    public int Update(CleanAgent update){
        String targetTable = "user";
        ContentValues updateData = new ContentValues();
        String whereClause = "token=?";
        String[] whereArgs = new String[]{String.format("%s",update.getToken())};
        updateData.put("username",update.getUsername());
        updateData.put("cleanerName",update.getCleanerName());
        updateData.put("cleanerNum",update.getCleanerNum());
        updateData.put("cleanerHeadImg",update.getCleanerHeadImg());
        SQLiteDatabase db = UDH.getWritableDatabase();
        int affectedRows = db.update(targetTable,updateData,whereClause,whereArgs);
        db.close();
        return affectedRows;
    }

    public CleanAgent query(String token){
        CleanAgent returnResult = new CleanAgent();
        returnResult.setToken(token);
        String targetTable = "user";
        String[] columns = new String[]{"username","cleanerName","cleanerNum","cleanerHeadImg"};
        String selection = "token=?";
        String[] selectionArgs = new String[]{String.format("%s",token)};
        SQLiteDatabase db = UDH.getReadableDatabase();
        Cursor queryResult = db.query(targetTable,columns,selection,selectionArgs,null,null,null);
        if (queryResult.moveToFirst())
        {
            returnResult.setUsername(queryResult.getString(0));
            returnResult.setCleanerName(queryResult.getString(1));
            returnResult.setCleanerNum(queryResult.getString(2));
            returnResult.setCleanerHeadImg(queryResult.getString(3));
        }
        queryResult.close();
        db.close();
        return returnResult;
    }

    public int delete(String token){
        String targetTable = "user";
        String whereClause = "token=?";
        String[] whereArgs = new String[]{String.format("%s",token)};
        SQLiteDatabase db = UDH.getWritableDatabase();
        int affectedRows = db.delete(targetTable,whereClause,whereArgs);
        db.close();
        return affectedRows;
    }
}
