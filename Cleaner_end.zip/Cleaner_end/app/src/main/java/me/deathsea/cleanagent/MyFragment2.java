package me.deathsea.cleanagent;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;

import android.widget.TextView;
import android.widget.Toast;


import java.io.IOException;
import java.io.InputStream;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import me.deathsea.cleanagent.Model.CleanAgent;


/**
 * Created by Jay on 2015/8/28 0028.
 */
public class MyFragment2 extends Fragment {

    private String TESTIMG = "http://i1.hdslb.com/bfs/face/8a2070f35fa4f539b53734498231e2768a678a17.jpg";
    private String TESTNAME = "邱俊雄";
    private String TESTNum = "1234567890";


    private boolean loginStat;
    private String username;
    private String token;
    private String cleanerName;
    private String cleanerHeadImg;
    private String cleanerNum;

    private TextView cleanName;
    private TextView cleanNum;
    private ImageView cleanImg;
    private TextView workTimeTextView;
    private TextView todayTaskTextView;
    private TextView scannStatusTextView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.myfragment2,container,false);
        cleanName = (TextView)view.findViewById(R.id.cleanerNameTextView);
        cleanImg = (ImageView)view.findViewById(R.id.cleanImg);
        cleanNum = (TextView)view.findViewById(R.id.cleanNum);
        workTimeTextView = (TextView)view.findViewById(R.id.workTime);
        //todayTaskTextView = (TextView)view.findViewById(R.id.todayTask);
        scannStatusTextView = (TextView)view.findViewById(R.id.scannStatus);

        tryGetStorageData();

        initTextView();
        initImg();


        workTimeTextView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),WorktimeActivity.class);
                startActivity(i);
            }
        });

        scannStatusTextView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent(getActivity(),scannStatusActivity.class);
                startActivity(i);
            }
        });
        return view;
    }

    public void onActivityCreated( Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (!loginStat){
            Toast.makeText(this.getActivity(),"你还没有登录！",Toast.LENGTH_LONG).show();
            Intent i = new Intent(this.getActivity(),LoginActivity.class);
            startActivity(i);
        }
    }


    private void initTextView(){
        cleanName.setText(cleanerName);
        cleanNum.setText(cleanerNum);
    }

    private void initImg(){
        AsyncTask<Void,Void,Bitmap> GetCF = new GetCleanInfo();
        GetCF.execute();
    }

    private class GetCleanInfo extends AsyncTask<Void,Void,Bitmap > {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        protected Bitmap doInBackground(Void... voids) {

            HttpURLConnection htc = null;


            try {
                URL loginurl = new URL(TESTIMG);
                htc = (HttpURLConnection) loginurl.openConnection();
                htc.setConnectTimeout(6000);
                htc.setRequestMethod("GET");
                htc.setDoInput(true);
                //htc.setChunkedStreamingMode(0);


                htc.connect();
                InputStream ist = htc.getInputStream();
                Bitmap result = BitmapFactory.decodeStream(ist);
                ist.close();
                return result;
            } catch (MalformedURLException E) {
                E.printStackTrace();
                Log.e("ERROR", "URL ERROR");
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("IOERROR", "ERROR");
            }

            if (htc != null) {
                htc.disconnect();
            }
            return null;
        }

//        @Override
//        protected void onProgressUpdate(Integer values) {
//            super.onProgressUpdate(values);
//            UpdateProgress.setProgress(values[0]);
//        }

        @Override
        protected void onPostExecute(Bitmap V) {
            super.onPostExecute(V);
            if (V!= null) {
                cleanImg.setImageBitmap(V);
            }
        }
    }

    private void tryGetStorageData() {
        UserDataOps SUO = new UserDataOps(getContext());
        CleanAgent storageData = SUO.HasData();
        String ErrMsg = "";
        if (storageData != null) {
            loginStat = true;
            username = storageData.getUsername();
            token = storageData.getToken();
            cleanerHeadImg = storageData.getCleanerHeadImg();
            cleanerName = storageData.getCleanerName();
            cleanerNum = storageData.getCleanerNum();
            //check if token is avalidable
            //check if token if outofdate
        }
        else{
            loginStat = false;
        }
    }
}
