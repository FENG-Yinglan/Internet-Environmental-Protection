package me.deathsea.cleanagent;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import me.deathsea.cleanagent.Model.CleanAgent;

public class LoginActivity extends Activity {
    //private int userid;
    private boolean loginStat;
    private String username;
    private String password;
    private String cleanerName;
    private String cleanerHeadImg;
    private String cleanerNum;
    private String token;

    private String LOGINURL = "http://aliy.w3.luyouxia.net/cUser/cleanerLoginByNameAndPwd";
    private EditText Username;
    private EditText Password;
    private ProgressDialog LoginProgress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if(loginStat){
            Intent i = new Intent(LoginActivity.this,Main2Activity.class);
            startActivity(i);
        }
        Username = (EditText)findViewById(R.id.username);
        Password = (EditText)findViewById(R.id.password);
        LoginProgress = new ProgressDialog(this);
        Button LoginButton = (Button) findViewById(R.id.LoginButton);
        LoginButton.setOnClickListener(new LoginClick());
    }

    class LoginClick implements View.OnClickListener
    {
        @Override
        public void onClick(View V)
        {
            username = Username.getText().toString();
            password = Password.getText().toString();
            LoginTask Lt = new LoginTask();
            Lt.execute(username,password);

        }
    }

    private class LoginTask extends AsyncTask<String ,Integer,Boolean >{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            LoginProgress.show();
            LoginProgress.setMax(100);
        }

        protected Boolean doInBackground(String...S){
            publishProgress(20);

            int length = S.length;
            if (length != 2 ){return false;}
            String username = S[0];
            String password = S[1];
            String Data = String.format("username=%s&password=%s",
                    username,password);
            HttpURLConnection htc = null;
            publishProgress(25);

            try {
                URL loginurl = new URL(LOGINURL);
                htc = (HttpURLConnection) loginurl.openConnection();
                htc.setRequestMethod("POST");
                htc.setDoOutput(true);
                //htc.setChunkedStreamingMode(0);
                publishProgress(30);

                OutputStreamWriter ops = new OutputStreamWriter(htc.getOutputStream());
                ops.write(Data);
                ops.flush();
                htc.connect();
                BufferedReader ist = new BufferedReader(
                        new InputStreamReader(
                                htc.getInputStream()));
                String Line;
                String JsonResult = "";
                while ((Line = ist.readLine()) != null){
                    JsonResult = JsonResult.concat(Line);
                }
                ist.close();
                htc.disconnect();
                publishProgress(50);

                try{
                    JSONObject resultdata = new JSONObject(JsonResult);
                    int error = resultdata.getInt("errorno");
                    //String errmsg = resultdata.getString("errmsg");
                    //Log.e("LoginJsonReturnErrorMSG",errmsg);
                    //Log.i("------json error num",String.format("%s",error));
                    publishProgress(100);
                    if (error != 0){return false;}
                    else{
                        JSONObject Logindata = resultdata.getJSONObject("data");
                        //NAME
                        //HEAD
                        //NUM
                        token = Logindata.getString("token");
                        cleanerName = Logindata.getString("name");
                        cleanerHeadImg = Logindata.getString("headImg");
                        cleanerNum = Logindata.getString("No");
//                        Log.i("----json get args:",String.format(
//                                "userid:%d,username:%s,token:%s,createDate:%d,validlength:%d",
//                                userid,username,token,createDate,validLength));

                        return true;
                    }
                }
                catch (Exception e){e.printStackTrace();}

                return true;
            }
            catch (MalformedURLException E)
            {
                E.printStackTrace();
                Log.e("ERROR","URL ERROR");
            }
            catch (IOException e)
            {
                e.printStackTrace();
                Log.e("IOERROR","ERROR");
            }
            publishProgress(100);
            if (htc!=null){htc.disconnect();}
            return false;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            LoginProgress.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            LoginProgress.dismiss();
            if(aBoolean){
                Toast.makeText(LoginActivity.this,"登录成功",Toast.LENGTH_LONG).show();
                jumpToIndex();
            }
            else{
                Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_LONG).show();
            }
        }
    }


    private void jumpToIndex(){
        Intent jump = new Intent(LoginActivity.this,Main2Activity.class);
        Bundle ResultData = new Bundle();
        ResultData.putBoolean("loginStat",true);
        ResultData.putString("username",username);
        ResultData.putString("token",token);
        ResultData.putString("cleanerHeadImg",cleanerHeadImg);
        ResultData.putString("cleanerName",cleanerName);
        ResultData.putString("cleanerNum",cleanerNum);

        jump.putExtra("ResultData",ResultData);
        startActivity(jump);
        finish();
    }

    private void tryGetStorageData() {
        UserDataOps SUO = new UserDataOps(this.getApplicationContext());
        CleanAgent storageData = SUO.HasData();
        String ErrMsg = "";
        if (storageData != null) {
            loginStat = true;
            username = storageData.getUsername();
            token = storageData.getToken();
            cleanerHeadImg = storageData.getCleanerHeadImg();
            cleanerName = storageData.getCleanerName();
            cleanerNum = storageData.getCleanerNum();
            //check if token is avalidable
            //check if token if outofdate
        }
        else{
            loginStat = false;
        }
    }
}
