package me.deathsea.cleanagent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.device.ScanDevice;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import me.deathsea.cleanagent.Model.CleanAgent;

/**
 * Created by deathsea on 2016-07-27.
 */
public class Main2Activity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener,
        ViewPager.OnPageChangeListener  {

    private boolean loginStat;
    private String username;
    private String token;
    private String cleanerName;
    private String cleanerHeadImg;
    private String cleanerNum;

    private RadioGroup rg_tab_bar;
    private RadioButton rb_channel;
    private RadioButton rb_message;
    private RadioButton rb_better;
    private ViewPager vpager;
    private ProgressDialog UpdateProgress;

    private ScanDevice sm;
    private final static String SCAN_ACTION = "scan.rcv.message";
    private String barcodeStr;

    private MyFragmentPagerAdapter mAdapter;

    //几个代表页面的常量
    public static final int PAGE_ONE = 0;
    public static final int PAGE_TWO = 1;
    public static final int PAGE_THREE = 2;

    private static final String UpdateUserScore = "http://aliy.w3.luyouxia.net/cUser/barcodeUpdate";

    private BroadcastReceiver mScanReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            byte[] barocode = intent.getByteArrayExtra("barocode");
            int barocodelen = intent.getIntExtra("length", 0);
            byte temp = intent.getByteExtra("barcodeType", (byte) 0);
            android.util.Log.i("debug", "----codetype--" + temp);
            barcodeStr = new String(barocode, 0, barocodelen);
            Log.i("scanner",barcodeStr);
            handlerScannerData(barcodeStr);

            //       showScanResult.setText(barcodeStr);
            sm.stopScan();
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tryGetStorageData();
        sm = new ScanDevice();
//        sm.setScannerType(0);qq
        sm.setOutScanMode(0);
        UpdateProgress = new ProgressDialog(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(SCAN_ACTION);
        mAdapter = new MyFragmentPagerAdapter(getSupportFragmentManager());
        bindViews();
        rb_channel.setChecked(true);

        Intent W = Main2Activity.this.getIntent();
        if (W != null) {
            Bundle loginData = W.getBundleExtra("ResultData");
            if (loginData != null) {
                loginStat = loginData.getBoolean("loginStat");
                if (loginStat) {
                    //LoginButton.setVisibility(View.INVISIBLE);
                    //LoginButton.setClickable(false);

                    username = loginData.getString("username");
                    token = loginData.getString("token");
                    cleanerHeadImg = loginData.getString("cleanerHeadImg");
                    cleanerName = loginData.getString("cleanerName");
                    cleanerNum = loginData.getString("cleanerNum");
                    saveUserData();

                }
            }
        }
    }

    private void bindViews() {
        rg_tab_bar = (RadioGroup) findViewById(R.id.rg_tab_bar);
        rb_channel = (RadioButton) findViewById(R.id.rb_channel);
        rb_message = (RadioButton) findViewById(R.id.rb_message);
        rb_better = (RadioButton) findViewById(R.id.rb_better);
        rg_tab_bar.setOnCheckedChangeListener(this);
        vpager = (ViewPager) findViewById(R.id.vpager);
        vpager.setAdapter(mAdapter);
        vpager.setCurrentItem(0);
        vpager.addOnPageChangeListener(this);
    }
    private void tryGetStorageData() {
        UserDataOps SUO = new UserDataOps(this.getApplicationContext());
        CleanAgent storageData = SUO.HasData();

        if (storageData != null) {
            loginStat = true;
            username = storageData.getUsername();
            token = storageData.getToken();
            cleanerHeadImg = storageData.getCleanerHeadImg();
            cleanerName = storageData.getCleanerName();
            cleanerNum = storageData.getCleanerNum();
        }
        else{
            loginStat = false;
        }
    }

    private void saveUserData() {
        CleanAgent thisData = null;
        UserDataOps SUD = new UserDataOps(this.getApplicationContext());
        if (SUD.HasToken(username)) {
            thisData = SUD.query(token);
            thisData.setCleanerHeadImg(cleanerHeadImg);
            thisData.setCleanerName(cleanerName);
            thisData.setCleanerNum(cleanerNum);
            SUD.Update(thisData);
        } else {
            thisData = new CleanAgent();
            thisData.setUsername(username);
            thisData.setToken(token);
            thisData.setCleanerHeadImg(cleanerHeadImg);
            thisData.setCleanerName(cleanerName);
            thisData.setCleanerNum(cleanerNum);
            SUD.Insert(thisData);
        }
    }
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.rb_channel:
                vpager.setCurrentItem(PAGE_ONE);
                break;
            case R.id.rb_message:
                vpager.setCurrentItem(PAGE_TWO);
                break;
            case R.id.rb_better:
                vpager.setCurrentItem(PAGE_THREE);
                break;
        }
    }


    //重写ViewPager页面切换的处理方法
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //state的状态有三个，0表示什么都没做，1正在滑动，2滑动完毕
        if (state == 2) {
            switch (vpager.getCurrentItem()) {
                case PAGE_ONE:
                    rb_channel.setChecked(true);
                    break;
                case PAGE_TWO:
                    rb_message.setChecked(true);
                    break;
                case PAGE_THREE:
                    rb_better.setChecked(true);
                    break;
            }
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if(sm != null) {
            sm.stopScan();
        }
        unregisterReceiver(mScanReceiver);
    }
    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(SCAN_ACTION);
        registerReceiver(mScanReceiver, filter);
    }

    private void handlerScannerData(final String barcodeStr){
        //实现带两个按钮的对话框
        //创建一个Builder对象
        if (!loginStat){
            Toast.makeText(Main2Activity.this,"你还没有登录！",Toast.LENGTH_LONG).show();
            Intent i = new Intent(Main2Activity.this,LoginActivity.class);
            startActivity(i);
            return;
        }
        String typeNum = barcodeStr.substring(barcodeStr.length() - 1);
        String type = "";
        switch (typeNum){
            case "1":
                type = "可回收垃圾";
                break;
            case "2":
                type = "厨余垃圾";
                break;
            case "3":
                type = "其他垃圾";
                break;
            case "4":
                type = "有害垃圾";
                break;
            default:
                type = "无分类";
                break;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(Main2Activity.this);
        builder.setTitle("该分类是："+type+"，分类正确吗？");
        builder.setIcon(android.R.drawable.btn_star);//设置图标
        builder.setMessage(barcodeStr);//设置内容
        builder.setPositiveButton("是", new DialogInterface.OnClickListener() {//设置确定按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();//关闭对话框
//                Toast.makeText(Main2Activity.this, "你选择了是" + which, Toast.LENGTH_LONG).show();
                UpdateResult R = new UpdateResult();
                R.execute(barcodeStr,String.valueOf(which));
            }
        });
        builder.setNegativeButton("否", new DialogInterface.OnClickListener() {//设置取消按钮
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
//                Toast.makeText(Main2Activity.this, "你选择了否" + which, Toast.LENGTH_LONG).show();
                UpdateResult R = new UpdateResult();
                R.execute(barcodeStr,String.valueOf(which));

            }
        });

        builder.create().show();//创建并显示对话框

    }

    private class UpdateResult extends AsyncTask<String ,Integer,Boolean > {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            UpdateProgress.show();
            UpdateProgress.setMax(100);
        }

        protected Boolean doInBackground(String...S){
            publishProgress(20);

            int length = S.length;
            String barcode = S[0];
            String state = S[1];
            String Data = String.format("token=%s&barcode=%s&state=%s",token,
                    barcode,state);
            HttpURLConnection htc = null;
            publishProgress(25);

            try {
                URL loginurl = new URL(UpdateUserScore);
                htc = (HttpURLConnection) loginurl.openConnection();
                htc.setRequestMethod("POST");
                htc.setDoOutput(true);
                //htc.setChunkedStreamingMode(0);
                publishProgress(30);

                OutputStreamWriter ops = new OutputStreamWriter(htc.getOutputStream());
                ops.write(Data);
                ops.flush();
                htc.connect();
                BufferedReader ist = new BufferedReader(
                        new InputStreamReader(
                                htc.getInputStream()));
                String Line;
                String JsonResult = "";
                while ((Line = ist.readLine()) != null){
                    JsonResult = JsonResult.concat(Line);
                }
                ist.close();
                htc.disconnect();
                publishProgress(50);

                try{
                    JSONObject resultdata = new JSONObject(JsonResult);
                    int error = resultdata.getInt("errorno");
                    //Log.i("------json error num",String.format("%s",error));
                    publishProgress(100);
                    if (error != 0){return false;}
                    else{
                        return true;
                    }
                }
                catch (Exception e){e.printStackTrace();}

                return true;
            }
            catch (MalformedURLException E)
            {
                E.printStackTrace();
                Log.e("ERROR","URL ERROR");
            }
            catch (IOException e)
            {
                e.printStackTrace();
                Log.e("IOERROR","ERROR");
            }
            publishProgress(100);
            if (htc!=null){htc.disconnect();}
            return false;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            UpdateProgress.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            UpdateProgress.dismiss();
            if(aBoolean){
                Toast.makeText(Main2Activity.this,"登记成功",Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(Main2Activity.this,"登记失败",Toast.LENGTH_LONG).show();
            }
        }
    }
}
