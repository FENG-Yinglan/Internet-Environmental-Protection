package me.deathsea.cleanagent;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import me.deathsea.cleanagent.Model.CleanAgent;


public class scannStatusActivity extends AppCompatActivity {


    private TextView scanCountTextView;
    private TextView sorceTextView;
    private ProgressDialog readStatusPB;

    private String scanCount = "22";
    private String sorce = "190";

    private String token;
    private String QueryStatusURL = "http://104.223.59.101:9999/cleanstatus";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scann_status);

        scanCountTextView = (TextView)findViewById(R.id.scanCountTextView);
        sorceTextView = (TextView)findViewById(R.id.sorceTextView);
        readStatusPB = new ProgressDialog(getApplicationContext());
        initTextView();
    }

    private void initTextView(){
        scanCountTextView.setText(scanCount);
        sorceTextView.setText(sorce);
    }

    private void tryGetStorageData() {
        UserDataOps SUO = new UserDataOps(getApplicationContext());
        CleanAgent storageData = SUO.HasData();
        String ErrMsg = "";
        if (storageData != null) {

            token = storageData.getToken();
        }
    }
    private class readStatus extends AsyncTask<Void, Void, Integer> {

        @Override
        protected void onPreExecute() {
            readStatusPB.show();
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            String Data = String.format("token=%s",token);
            HttpURLConnection htc = null;
            try {
                URL loginurl = new URL(QueryStatusURL);
                htc = (HttpURLConnection) loginurl.openConnection();
                htc.setRequestMethod("POST");
                htc.setDoOutput(true);
                OutputStreamWriter ops = new OutputStreamWriter(htc.getOutputStream());
                ops.write(Data);
                ops.flush();
                htc.connect();
                BufferedReader ist = new BufferedReader(
                        new InputStreamReader(
                                htc.getInputStream()));
                String Line;
                String JsonResult = "";
                while ((Line = ist.readLine()) != null) {
                    JsonResult = JsonResult.concat(Line);
                }
                ist.close();
                htc.disconnect();

                try {
                    JSONObject resultdata = new JSONObject(JsonResult);
                    int error = resultdata.getInt("errorno");
                    String errmsg = resultdata.getString("errmsg");
                    Log.e("LoginJsonReturnErrorMSG", errmsg);
                    //Log.i("------json error num",String.format("%s",error));
                    if (error != 0) {
                        return error;
                    } else {
                        JSONObject tokenData = resultdata.getJSONObject("data");
                        scanCount = tokenData.getString("scanCount");
                        sorce = tokenData.getString("cleanersorce");
                        return 111;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return -1;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            String ErrMsg = "";
            switch (integer) {
                case 512://out date
                    ErrMsg = "Token out of date,please relogin";
                    break;
                case 256://token error
                    ErrMsg = "Token invalid ,please relogin";
                    break;
                case 111://token error
                    ErrMsg = "Token invalid ,please relogin";
                    break;
                case -1://network error
                    ErrMsg = "NetWork Error";
                    break;
                case 0:
                    readStatusPB.dismiss();
                    return;
                default:
                    ErrMsg = "Unknow Error";

            }
            readStatusPB.dismiss();
            Toast.makeText(getApplicationContext(), ErrMsg, Toast.LENGTH_LONG).show();
        }

    }
}
