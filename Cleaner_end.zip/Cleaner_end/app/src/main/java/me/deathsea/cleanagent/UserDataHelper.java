package me.deathsea.cleanagent;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by deathsea on 2016/7/18.
 */
public final class UserDataHelper extends SQLiteOpenHelper{
    private static String SQL_CREATE_S = "create table user("+
            "token varchar(100) primary key," +
            "username varchar(100),"+
            "cleanerName varchar(100),"+
            "cleanerNum varchar(20),"+
            "cleanerHeadImg varchar(200)"+
            ");";
    private static String SQL_DELETE_S = "drop table if exists user;";
    private final static String DATABASE_NAME = "cleanagent.db";
    private final static int DATABASE_VERSION = 2;
    public UserDataHelper(Context context){super(context,DATABASE_NAME,null,DATABASE_VERSION);}
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_CREATE_S);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(SQL_DELETE_S);
        onCreate(sqLiteDatabase);
    }
}
