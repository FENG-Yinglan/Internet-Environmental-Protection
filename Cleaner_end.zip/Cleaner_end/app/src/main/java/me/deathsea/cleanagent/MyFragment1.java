package me.deathsea.cleanagent;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.device.ScanDevice;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import me.deathsea.cleanagent.Model.CleanAgent;

/**
 * Created by Jay on 2015/8/28 0028.
 */
public class MyFragment1 extends Fragment {

    private boolean loginStat;

    private String username;
    private String token;
    private String password;
    private String cleanerName;
    private String cleanerHeadImg;
    private String cleanerNum;



    private View thisView;

    private LinearLayout Gallery;
    private String[] Data;
    private Button LoginButton;
    private HorizontalScrollView horizontalscrollview;
    private ProgressDialog TokenProgress;

    private String LOGINURL = "http://aliy.w3.luyouxia.net/cUser/cleanerLoginByToken";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        thisView = inflater.inflate(R.layout.myfragment1, container, false);
        return thisView;
    }
    public void onActivityCreated( Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        loginStat = false;
        LoginButton = (Button) thisView.findViewById(R.id.Loginbutton);


        horizontalscrollview = (HorizontalScrollView) thisView.findViewById(R.id.WorkInfor);
        TokenProgress = new ProgressDialog(getContext());
        InitData();
        InitView();
        final Handler Timerhandler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                int off = horizontalscrollview.getScrollX()
                        + horizontalscrollview.getMeasuredWidth(); // 目标X值
                int maxScrollX = horizontalscrollview.getChildAt(0).getMeasuredWidth() -
                        horizontalscrollview.getMeasuredWidth();//最大X值
                if (off <= maxScrollX) {
                    horizontalscrollview.smoothScrollTo(
                            off, 0);
                } else {
                    horizontalscrollview.smoothScrollTo(0, 0);
                }
                Timerhandler.postDelayed(this, 2000);
            }
        };
        Timerhandler.postDelayed(runnable, 2000);


        tryGetStorageData();

        LoginButton.setOnClickListener(new loginClickListen());


    }


    private void InitData() {
        Data = new String[]{"今天下午6点开会", "国庆放假说明", "新员工勉励政策出台", "喵喵喵",
                "汪汪汪", "嘎嘎嘎"};
    }

    private void InitView() {
        Gallery = (LinearLayout) thisView.findViewById(R.id.WorkInforSlide);
        for (int index = 0; index < Data.length; index++) {
            TextView Ed = new TextView(getContext());
            Ed.setText(Data[index]);
            //Ed.setTextAppearance(?android:attr/textAppearanceLarge);
            Ed.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 50);
            Ed.setHeight((int) (getResources().getDisplayMetrics().heightPixels * 0.6));
            Ed.setWidth(getResources().getDisplayMetrics().widthPixels);
            Ed.setGravity(Gravity.CENTER);
            Gallery.addView(Ed);
        }
    }

    class loginClickListen implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if (!loginStat) {
                Intent JumpToLogin = new Intent(getActivity(), LoginActivity.class);
                startActivity(JumpToLogin);
                getActivity().finish();
            } else {
                deleteStorageData();
                Toast.makeText(getContext(), "退出成功", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void saveUserData() {
        CleanAgent thisData = null;
        UserDataOps SUD = new UserDataOps(getContext());
        if (SUD.HasToken(username)) {
            thisData = SUD.query(token);
            thisData.setCleanerHeadImg(cleanerHeadImg);
            thisData.setCleanerName(cleanerName);
            thisData.setCleanerNum(cleanerNum);
            SUD.Update(thisData);
        } else {
            thisData = new CleanAgent();
            thisData.setUsername(username);
            thisData.setToken(token);
            thisData.setCleanerHeadImg(cleanerHeadImg);
            thisData.setCleanerName(cleanerName);
            thisData.setCleanerNum(cleanerNum);
            SUD.Insert(thisData);
        }
    }

    private void tryGetStorageData() {
        UserDataOps SUO = new UserDataOps(getContext());
        CleanAgent storageData = SUO.HasData();
        String ErrMsg = "";
        if (storageData != null) {
            loginStat = true;
            username = storageData.getUsername();
            token = storageData.getToken();
            cleanerHeadImg = storageData.getCleanerHeadImg();
            cleanerName = storageData.getCleanerName();
            cleanerNum = storageData.getCleanerNum();
            LoginButton.setText(R.string.stringLogout);
            //check if token is avalidable
            //check if token if outofdate
            //checkToken Check = new checkToken();
            //Check.execute();
        }
    }

    private void deleteStorageData() {
        loginStat = false;
        UserDataOps DUDO = new UserDataOps(getContext());
        DUDO.delete(token);

        username = null;
        token = null;
        cleanerHeadImg = null;
        cleanerName = null;
        cleanerNum = null;

        LoginButton.setText(R.string.StringLogin);
    }

    private class checkToken extends AsyncTask<Void, Void, Integer> {

        @Override
        protected void onPreExecute() {
            TokenProgress.show();
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            String Data = String.format("token=%s",token);
            HttpURLConnection htc = null;
            try {
                URL loginurl = new URL(LOGINURL);
                htc = (HttpURLConnection) loginurl.openConnection();
                htc.setRequestMethod("POST");
                htc.setDoOutput(true);
                OutputStreamWriter ops = new OutputStreamWriter(htc.getOutputStream());
                ops.write(Data);
                ops.flush();
                htc.connect();
                BufferedReader ist = new BufferedReader(
                        new InputStreamReader(
                                htc.getInputStream()));
                String Line;
                String JsonResult = "";
                while ((Line = ist.readLine()) != null) {
                    JsonResult = JsonResult.concat(Line);
                }
                ist.close();
                htc.disconnect();

                try {
                    JSONObject resultdata = new JSONObject(JsonResult);
                    int error = resultdata.getInt("errorno");
                    //Log.i("------json error num",String.format("%s",error));
                    if (error != 0) {
                        return error;
                    } else {
                        JSONObject tokenData = resultdata.getJSONObject("data");
                        String noindata = String.valueOf(tokenData.getInt("No"));
                        if (noindata == cleanerNum) {
                            return 0;
                        }
                        return 111;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return -1;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            String ErrMsg = "";
            switch (integer) {
                case 512://out date
                    ErrMsg = "Token out of date,please relogin";
                    break;
                case 256://token error
                    ErrMsg = "Token invalid ,please relogin";
                    break;
                case 111://token error
                    ErrMsg = "Token invalid ,please relogin";
                    break;
                case -1://network error
                    ErrMsg = "NetWork Error";
                    break;
                case 0:
                    TokenProgress.dismiss();
                    return;
                default:
                    ErrMsg = "Unknow Error";

            }
            TokenProgress.dismiss();
            Toast.makeText(getContext(), ErrMsg, Toast.LENGTH_LONG).show();
            deleteStorageData();
        }

    }


}
