package me.deathsea.cleanagent;

import android.app.Application;
import android.content.Context;
import android.test.ApplicationTestCase;
import android.util.Log;

import me.deathsea.cleanagent.Model.CleanAgent;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
    public void testTEST(){
        UserDataHelper UDP = new UserDataHelper(getContext());
        ;
        UDP.close();
        Log.i("","pppppppppppppppppppppppppp");
    }

    public void testUserToken(){
        UserDataOps UDO = new UserDataOps(getContext());
        boolean token = UDO.HasToken("test11");
        Log.i("test token:",token?"true":"false");
    }

    public void testInsert()
    {
        CleanAgent TEST = new CleanAgent();
        TEST.setUsername("admin");
        TEST.setToken("saio21ijda03rjea039ejdz");
        TEST.setCleanerNum("1");
        TEST.setCleanerHeadImg("13213123");
        TEST.setCleanerName("aaaaaaaaa");
        UserDataOps ISO = new UserDataOps(getContext());
        long result = ISO.Insert(TEST);
        Log.i("-------------------",String.format("%d",result));
    }

    public void testUpdate()
    {
        CleanAgent TEST = new CleanAgent();
        TEST.setUsername("fuckyou");
        TEST.setToken("saio21ijda03rjea039ejdz");
        UserDataOps USO = new UserDataOps(getContext());
        int result = USO.Update(TEST);
        Log.i("-------update-------",String.format("%d",result));
    }
}
