define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	var sendJson = require("$UI/Ljrecy/sendJson");
	var type = "start";
	var startDate = new Date();
	var endDate = new Date();

	var Model = function(){
		this.callParent();
	};

	Model.prototype.selectDate = function(event){
		var xid = event.source.getXid();
		var dateP = this.comp("dateP");

		switch(xid){
			case "startDate":
				type = "start";
				dateP.set("min",null);
				dateP.set("max",new Date());
				break;
			case "endDate":
				type = "end";
				dateP.set("min",startDate);
				dateP.set("max",new Date(startDate - 0 + 30*24*3600*1000));
				break;
		}
		dateP.set("type","date");
		dateP.show();
		dateP.setValue(startDate);
	};
	
	Model.prototype.dateSelectOK = function(event){
		value = event.source.getValue();
		switch(type){
			case "start":
				this.comp("startDate").set({"label":justep.Date.toString(value,"yyyy年MM月dd日")});
				this.comp("startDate").setCSS({color:"#000000"});
				startDate = value;
				break;
			case "end":
				this.comp("endDate").set({"label":justep.Date.toString(value,"yyyy年MM月dd日")});
				this.comp("endDate").setCSS({color:"#000000"});
				endDate = value;
				break;
		}
	};
	
	
	Model.prototype.button8Click = function(event){
		var me = this;
		var token = localStorage.getItem("token");
		var resultData = this.comp("data1");
		function su(resultdata,xhr){
			var data = resultdata.data;
			var list = data.list;
			resultData.clear();
			list.forEach(function(obj){
				resultData.add({
				date:justep.Date.toString(justep.Date.fromString(obj.date, "yyyy-MM-dd"), "yyyy-MM-ddThh:mm:ss.000Z"),
				type:
				function(type){switch(type){
				case 0:return "新用户注册增送";
				case 1:return "环保知识问答奖励";
				case 2:return "游戏奖励";
				case 3:return "积分消费";
				case 4:return "垃圾分类正确奖励";}}(obj.type),
				count:obj.num});
			});
			me.comp("dataTables2").refresh();
			
		}
		
		function err(msg,xhr){
			me.comp("msgDig").show({
				title:"查询出错",
				message:"网络错误"
			});
		}
		
		var params = {"token":token,
		"start":justep.Date.toString(startDate,"yyyy-MM-dd"),
		"end":justep.Date.toString(endDate,"yyyy-MM-dd")};
		sendJson.sendRequest({
        	"baseUrl":"http://aliy.w3.luyouxia.net",
            "url" : "/mUser", // servlet请求地址
            "action" : "score", // action
            "params" : params, // action对应的参数
            "success" : su, // 请求成功后的回调方法
            "error":err
		});

	};
	
	
	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};
	
	
	return Model;
});