define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	var sendJson = require("$UI/Ljrecy/sendJson");

	var Model = function(){
		this.callParent();
	};
	Model.prototype.open = function(event,id) {
	var childPageWinPage = this.comp("childPageWinPage");
	var Xid = event.source.getXid();	
	switch(Xid){
	case "button1":
		childPageWinPage.open({"src":"$UI/Ljrecy/3/scoreStatus.w"});
		break;
	case "button2":
		childPageWinPage.open({"src":require.toUrl("../shop/mainActivity.w")});
		break;	
	}
	};

	Model.prototype.modelLoad = function(event){
		var token = localStorage.getItem("token");
		var params = {"token":token};
		
		function su(result,xhr){
			localStorage.setItem("score",result.data.score);
		}
		
		sendJson.sendRequest({
	        "baseUrl":"http://aliy.w3.luyouxia.net",
	        "url" : "/mUser", // servlet请求地址
	        "action" : "info", // action
	        "params" : params, // action对应的参数
	        "success" :  su// 请求成功后的回调方法
	        });	
	        
	    this.comp("button3").set({label:"当前积分："+localStorage.getItem("score")});
	};

	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};

	return Model;
});