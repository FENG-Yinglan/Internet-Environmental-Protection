define(function(require){
	//var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	
	var Model = function(){
		this.callParent();
	};
	
	Model.prototype.getImageUrl = function(row) {
		return require.toUrl(row.val('imgUrl'));
	};
	
	
	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};

	
	Model.prototype.button4Click = function(event){
		this.comp("windowDialog1").open();
	};

	
	return Model;
});