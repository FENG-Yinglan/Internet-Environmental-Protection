define(function(require){
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/windowReceiver/windowReceiver');
require('$model/UI2/system/components/justep/row/row');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/windowDialog/windowDialog');
require('$model/UI2/system/components/justep/window/window');
require('$model/UI2/system/components/justep/messageDialog/messageDialog');
require('$model/UI2/system/components/justep/panel/panel');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Ljrecy/channel/menu1Pic2'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='cim6nii';
	this._flag_='693697c11e1636f5ee4f2b64bdbfecd7';
	this.callParent(contextUrl);
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"id":{"define":"id","label":"id","name":"id","relation":"id","rules":{"integer":true},"type":"Integer"},"img":{"define":"img","label":"图片路径","name":"img","relation":"img","type":"String"},"name":{"define":"name","label":"名称","name":"name","relation":"name","type":"String"}},"directDelete":false,"events":{},"idColumn":"id","initData":"[ {\"id\":0,\"name\":\"标签打印情况\",\"img\":\"$UI/Ljrecy/channel/img/MyMc0.jpg\"}, {\"id\":1,\"name\":\"账号详情\",\"img\":\"$UI/Ljrecy/channel/img/MyMc1.jpg\"}, {\"id\":2,\"name\":\"我的钱包\",\"img\":\"$UI/Ljrecy/channel/img/MyMc2.jpg\"}, {\"id\":3,\"name\":\"设置\",\"img\":\"$UI/Ljrecy/channel/img/MyMc3.jpg\"} ]","limit":20,"xid":"data1"});
}}); 
return __result;});