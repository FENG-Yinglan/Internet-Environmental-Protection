define(function(require){
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/list/list');
require('$model/UI2/system/components/justep/output/output');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/window/window');
require('$model/UI2/system/components/justep/panel/panel');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Ljrecy/channel/friendsRank'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='cuyqmme';
	this._flag_='d9e74f821b3e993051ec862f56c6f647';
	this.callParent(contextUrl);
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"id":{"define":"id","name":"id","relation":"id","rules":{"integer":true},"type":"Integer"},"rank":{"define":"rank","label":"排名","name":"rank","relation":"rank","rules":{"integer":true},"type":"Integer"},"sroce":{"define":"sroce","label":"积分","name":"sroce","relation":"sroce","type":"String"},"usrName":{"define":"usrName","label":"用户名","name":"usrName","relation":"usrName","type":"String"}},"directDelete":false,"events":{},"idColumn":"id","initData":"[{\"id\":22,\"rank\":1,\"usrName\":\"188****3690\",\"sroce\":\"579\"},{\"id\":33,\"rank\":2,\"usrName\":\"156****9023\",\"sroce\":\"498\"},{\"id\":44,\"rank\":3,\"usrName\":\"133****7640\",\"sroce\":\"456\"}]","limit":20,"xid":"data1"});
}}); 
return __result;});