define(function(require){
	var $ = require("jquery");
	//var justep = require("$UI/system/lib/justep");
	var sendJson = require("$UI/Ljrecy/sendJson");
	require("$UI/Ljrecy/channel/jqueryQR");
	
	var Model = function(){
		this.callParent();
	};
	function saveUsrInfo(result){
		var ret = result.data;
		localStorage.setItem("area",ret.area);
		localStorage.setItem("city",ret.city);
		localStorage.setItem("head",ret.head);
		localStorage.setItem("idcard",ret.idcard);
		localStorage.setItem("province",ret.province);
		localStorage.setItem("score",ret.score);
		localStorage.setItem("sex",ret.sex);
		localStorage.setItem("signature",ret.signature);
		localStorage.setItem("street",ret.street);
		localStorage.setItem("token",ret.token);
		localStorage.setItem("name",ret.username);
		localStorage.setItem("nickName",ret.nickname);
	}
	

	Model.prototype.onLoad = function(){
		var token = localStorage.getItem("token");
		if (token.length === 0 || localStorage.getItem("name").length === 0){
			if (token.length === 0){
				localStorage.setItem("loginStatus",0);
				alert("程序出错，请重新登录");
				this.comp("chlidPageDig").open({"src":require.toUrl("../login.w")});
				
			}
			else{
				var params = {"token":token};
				sendJson.sendRequest({
		        	"baseUrl":"http://aliy.w3.luyouxia.net",
		            "url" : "/mUser", // servlet请求地址
		            "action" : "info", // action
		            "params" : params, // action对应的参数
		            "success" :  saveUsrInfo// 请求成功后的回调方法
				});
			}
		}
		//var head = localStorage.getItem("head");
		var name = localStorage.getItem("name");
		var username = localStorage.getItem("username");
		
		$("img[xid=image1]").attr("src","http://aliy.w3.luyouxia.net/mUser/headImg?token="+token);
		$("span[xid=label1]").text(name);
		$("span[xid=label2]").text(username);
		var qr = this.getElementByXid("image2");
		$(qr).qrcode({render:"image",
		size:300,
		text:token});
	};
	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};
	return Model;
});