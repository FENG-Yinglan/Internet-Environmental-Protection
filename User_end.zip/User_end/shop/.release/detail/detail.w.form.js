define(function(require){
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/row/row');
require('$model/UI2/system/components/justep/list/list');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/window/window');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Ljrecy/shop/detail'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='czA7j2e';
	this._flag_='2fb068e65449685da88440fb4465f671';
	this.callParent(contextUrl);
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"color":{"define":"color","label":"颜色","name":"color","relation":"color","type":"String"},"content":{"define":"content","label":"内容","name":"content","relation":"content","type":"String"},"id":{"define":"id","label":"ID","name":"id","relation":"id","type":"String"},"image":{"define":"image","label":"头像","name":"image","relation":"image","type":"String"},"name":{"define":"name","label":"名称","name":"name","relation":"name","type":"String"},"time":{"define":"time","label":"时间","name":"time","relation":"time","type":"String"}},"directDelete":false,"events":{"onCustomRefresh":"commentCustomRefresh"},"idColumn":"id","limit":20,"xid":"comment"});
}}); 
return __result;});