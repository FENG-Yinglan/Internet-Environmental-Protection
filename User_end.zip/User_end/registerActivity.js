define(function(require) {
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	var sendJson = require("$UI/Ljrecy/sendJson");

	function checkID(ID) {
		if (typeof ID !== 'string')
			return '非法字符串';
		var city = {
			11 : "北京",
			12 : "天津",
			13 : "河北",
			14 : "山西",
			15 : "内蒙古",
			21 : "辽宁",
			22 : "吉林",
			23 : "黑龙江 ",
			31 : "上海",
			32 : "江苏",
			33 : "浙江",
			34 : "安徽",
			35 : "福建",
			36 : "江西",
			37 : "山东",
			41 : "河南",
			42 : "湖北 ",
			43 : "湖南",
			44 : "广东",
			45 : "广西",
			46 : "海南",
			50 : "重庆",
			51 : "四川",
			52 : "贵州",
			53 : "云南",
			54 : "西藏 ",
			61 : "陕西",
			62 : "甘肃",
			63 : "青海",
			64 : "宁夏",
			65 : "新疆",
			71 : "台湾",
			81 : "香港",
			82 : "澳门",
			91 : "国外"
		};
		var birthday = ID.substr(6, 4) + '/' + Number(ID.substr(10, 2)) + '/' + Number(ID.substr(12, 2));
		var d = new Date(birthday);
		var newBirthday = d.getFullYear() + '/' + Number(d.getMonth() + 1) + '/' + Number(d.getDate());
		var currentTime = new Date().getTime();
		var time = d.getTime();
		var arrInt = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 ];
		var arrCh = [ '1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2' ];
		var sum = 0, i, residue;

		if (!/^\d{17}(\d|x)$/i.test(ID))
			return '非法身份证';
		if (city[ID.substr(0, 2)] === undefined)
			return "非法地区";
		if (time >= currentTime || birthday !== newBirthday)
			return '非法生日';
		for (i = 0; i < 17; i++) {
			sum += ID.substr(i, 1) * arrInt[i];
		}
		residue = arrCh[sum % 11];
		if (residue !== ID.substr(17, 1))
			return '非法校验码';

		return true;
	}

	var Model = function() {
		this.callParent();
	};

	Model.prototype.regBtnClick = function(event) {
		
		var loginName = this.comp("loginName").val();
		var password = this.comp("password").val();
		var repassword = this.comp("repassword").val();
		var usrName = this.comp("userName").val();
		var CardID = this.comp("cardID").val();
		var sex = this.comp("sexselect").val();
		var province = this.comp("provinceSelect").val();
		var city = this.comp("citySelect").val();
		var district = this.comp("districtSelect").val();
		var street = this.comp("street").val();
		var msgDig = this.comp("msgDig");

		var FLAG = true;
		var ErrMsg = "";
		var me = this;

		if (loginName.length === 0) {
			ErrMsg += "用户名不能为空\n";
			FLAG = false;
		}
		if (password.length === 0) {
			ErrMsg += "密码不能为空\n";
			FLAG = false;
		}
		if (repassword.length === 0) {
			ErrMsg += "确认密码不能为空\n";
			FLAG = false;
		}
		if (usrName.length === 0) {
			ErrMsg += "姓名不能为空\n";
			FLAG = false;
		}
		if (CardID.length === 0) {
			ErrMsg += "身份号不能为空\n";
			FLAG = false;
		}
		if (sex.length === 0) {
			ErrMsg += "性别不能为空\n";
			FLAG = false;
		}
		if (password.length !== 0 && (password.length > 16 || password.length < 6)) {
			ErrMsg += "密码长度不正确\n";
			FLAG = false;
		}
		if (password.length !== 0 && !/[\d\w]{6,16}/.test(password)) {
			ErrMsg += "密码格式不正确\n";
			FLAG = false;
		}
		if (password.length !== 0 && repassword.length !== 0 && password !== repassword) {
			ErrMsg += "确认密码与密码不一致\n";
			FLAG = false;
		}
		if (CardID.length !== 0 && checkID(CardID) !== true){
			ErrMsg += "身份证信息错误："+checkID(CardID)+"\n";
			FLAG = false;
		}

		function su(ret,xhr){
			if(ret.errorno !== 0){
				ErrMsg = ret.errMsg;
				msgDig.show({
					type : "OK",
					title : "注册失败",
					message : "用户名已存在",
				});
			} 
			else{
				msgDig.show({
					type:"OK",
					title:"注册成功",
				});
				me.comp("windowReceiver1").windowEnsure();
			}
		};
		function err(ret,xhr){
				msgDig.show({
					type : "OK",
					title : "注册失败",
					message : "网络错误",
				});
		};


		if (FLAG) {
		
			var params = {
				"loginName" : loginName,
				"password" : password,
				"nickName":usrName,
				"userName" : usrName,
				"sex" : sex,
				"idCardNo" : CardID,
				"province" : province,
				"city" : city,
				"area" : district,
				"street" : street,
			};
//			justep.Baas.sendRequest({
//				"url" : "/recycler/user", // servlet请求地址
//				"action" : "userReg", // action
//				"params" : params, // action对应的参数
//				"success" : su,// 请求成功后的回调方法
//				"error":err
//			});
			sendJson.sendRequest({    
	        	"baseUrl":"http://aliy.w3.luyouxia.net",
	            "url" : "/mUser", // servlet请求地址
	            "action" : "reg", // action
	            "params" : params, // action对应的参数
	            "success" : su, // 请求成功后的回调方法
	            "error":err,
	        });
		} else {
			msgDig.show({
				type : "OK",
				title : "请更正以下错误",
				message : ErrMsg,
			});
		}
	};

	return Model;
});