define(function(require) {
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");

	var Model = function() {
		this.callParent();
	};
	if (localStorage.getItem("loginStatus") == 1) {
		// Model.comp("button1").set({"label":"注销","span5":"注销"});
		// Model.getComponent("button1").set("label", "注销")
		$("a[xid=button1]").text("注销");
	}

	Model.prototype.toUrl = function(param) {
		return require.toUrl(param);
	};

	Model.prototype.open = function(event) {
		var row = event.bindingContext.$object;
		var url = row.val('imgUrl');
		var loginStatus = localStorage.getItem("loginStatus");
		var childPageWinDig = this.comp("childPageWinDig");
		if (loginStatus == 1) {
			childPageWinDig.open({"src":require.toUrl(url)});
		} else {
			this.comp("loginDialog").open();
		}
	};

	Model.prototype.login = function(event) {
		// justep.Shell.showPage(require.toUrl("LoginActivity.w"));
		var loginStatus = localStorage.getItem("loginStatus");
		if (loginStatus != 1) {
			this.comp("loginDialog").open();
		} else {
//			alert("注销");
			localStorage.setItem("loginStatus", 0);
			if (localStorage.getItem("remMe") == 0){
				localStorage.removeItem("username");
				localStorage.removeItem("password");
			}
			this.comp("button1").set({"label":"登录"});
			$("a[xid=button1]").text("登录");
		}
	};
	Model.prototype.loginDialogReceived = function(event) {
		var loginStatus = localStorage.getItem("loginStatus");
		if (loginStatus == 1) {
			$("a[xid=button1]").text("注销");

		}
	};

	return Model;
});