window.__justep.__ResourceEngine.loadCss([{url: '/v_7c50ec15533e451baf3c3e3ba56b0abel_zh_CNs_d_m/system/components/bootstrap.min.css', include: '$model/system/components/bootstrap/lib/css/bootstrap,$model/system/components/bootstrap/lib/css/bootstrap-theme'},{url: '/v_8e5b3b766610449aa830e520fcd5cf84l_zh_CNs_d_m/system/components/comp.min.css', include: '$model/system/components/justep/lib/css2/dataControl,$model/system/components/justep/input/css/datePickerPC,$model/system/components/justep/messageDialog/css/messageDialog,$model/system/components/justep/lib/css3/round,$model/system/components/justep/input/css/datePicker,$model/system/components/justep/row/css/row,$model/system/components/justep/attachment/css/attachment,$model/system/components/justep/barcode/css/barcodeImage,$model/system/components/bootstrap/dropdown/css/dropdown,$model/system/components/justep/dataTables/css/dataTables,$model/system/components/justep/contents/css/contents,$model/system/components/justep/common/css/forms,$model/system/components/justep/locker/css/locker,$model/system/components/justep/menu/css/menu,$model/system/components/justep/scrollView/css/scrollView,$model/system/components/justep/loadingBar/loadingBar,$model/system/components/justep/dialog/css/dialog,$model/system/components/justep/bar/css/bar,$model/system/components/justep/popMenu/css/popMenu,$model/system/components/justep/lib/css/icons,$model/system/components/justep/lib/css4/e-commerce,$model/system/components/justep/toolBar/css/toolBar,$model/system/components/justep/popOver/css/popOver,$model/system/components/justep/panel/css/panel,$model/system/components/bootstrap/carousel/css/carousel,$model/system/components/justep/wing/css/wing,$model/system/components/bootstrap/scrollSpy/css/scrollSpy,$model/system/components/justep/titleBar/css/titleBar,$model/system/components/justep/lib/css1/linear,$model/system/components/justep/numberSelect/css/numberList,$model/system/components/justep/list/css/list,$model/system/components/justep/dataTables/css/dataTables'}]);window.__justep.__ResourceEngine.loadJs(['/v_6012c820e6ac48c7b7c6ec8d3734eb5el_zh_CNs_d_m/system/components/comp2.min.js','/v_ccb2a8048dd541138dd8c13a46834dael_zh_CNs_d_m/system/core.min.js','/v_8d5883e1352543a49c461a36541d5fd6l_zh_CNs_d_m/system/common.min.js','/v_11f3f7f53a4b44419d9ca98dcf5250e7l_zh_CNs_d_m/system/components/comp.min.js']);define(function(require){
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/list/list');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/windowDialog/windowDialog');
require('$model/UI2/system/components/justep/panel/panel');
require('$model/UI2/system/components/justep/contents/content');
require('$model/UI2/system/components/bootstrap/carousel/carousel');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/contents/contents');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/window/window');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Ljrecy/mainActivity'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='cArAJrm';
	this._flag_='29354cfbc3baf6bfe7b4ce952609fdd7';
	this.callParent(contextUrl);
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"icon":{"define":"icon","label":"icon","name":"icon","relation":"icon","type":"String"},"id":{"define":"id","label":"id","name":"id","relation":"id","type":"String"},"imgUrl":{"define":"imgUrl","label":"imgUrl","name":"imgUrl","relation":"imgUrl","type":"String"},"title":{"define":"title","label":"title","name":"title","relation":"title","type":"String"}},"directDelete":false,"events":{},"idColumn":"id","initData":"[ {\"id\":\"1\",\"icon\":\"./img/menu_qr_t.png\",\"title\":\"二维码\",\"imgUrl\":\"./channel/menu1Pic1.w\"}, {\"id\":\"2\",\"icon\":\"./img/menu_mymc.png\",\"title\":\"我的MC\",\"imgUrl\":\"./channel/menu1Pic2.w\"}, {\"id\":\"4\",\"icon\":\"./img/menu_store.png\",\"title\":\"商城\",\"imgUrl\":\"./shop/mainActivity.w\"}, {\"id\":\"5\",\"icon\":\"./img/menu_funmc.png\",\"title\":\"趣味MC\",\"imgUrl\":\"./channel/menu1Pic4.w\"}, ]","limit":20,"xid":"data"});
}}); 
return __result;});
