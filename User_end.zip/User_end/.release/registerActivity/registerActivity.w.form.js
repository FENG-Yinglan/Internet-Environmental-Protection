define(function(require){
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/distpicker/districtSelect');
require('$model/UI2/system/components/justep/controlGroup/controlGroup');
require('$model/UI2/system/components/justep/input/input');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/messageDialog/messageDialog');
require('$model/UI2/system/components/justep/labelEdit/labelEdit');
require('$model/UI2/system/components/justep/distpicker/provinceSelect');
require('$model/UI2/system/components/justep/panel/panel');
require('$model/UI2/system/components/justep/input/password');
require('$model/UI2/system/components/justep/select/select');
require('$model/UI2/system/components/justep/row/row');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/window/window');
require('$model/UI2/system/components/justep/distpicker/citySelect');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Ljrecy/registerActivity'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='c3YF3If';
	this._flag_='6208e56be80047af66aa3056d9f20aa0';
	this.callParent(contextUrl);
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"col0":{"define":"col0","name":"col0","relation":"col0","type":"String"},"col1":{"define":"col1","name":"col1","relation":"col1","type":"String"},"col2":{"define":"col2","name":"col2","relation":"col2","type":"String"}},"directDelete":false,"events":{},"idColumn":"col0","initData":"[{}]","limit":20,"xid":"data1"});
 new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"area":{"define":"area","label":"区：","name":"area","relation":"area","type":"String"},"cardID":{"define":"cardID","label":"身份证号 ","name":"cardID","relation":"cardID","type":"String"},"city":{"define":"city","label":"市：","name":"city","relation":"city","type":"String"},"id":{"define":"id","name":"id","relation":"id","rules":{"integer":true},"type":"Integer"},"loginName":{"define":"loginName","label":"用户名：","name":"loginName","relation":"loginName","type":"String"},"name":{"define":"name","label":"姓名：","name":"name","relation":"name","type":"String"},"password":{"define":"password","label":"密码：","name":"password","relation":"password","type":"String"},"province":{"define":"province","label":"省份：","name":"province","relation":"province","type":"String"},"repwd":{"define":"repwd","label":"确认密码：","name":"repwd","relation":"repwd","type":"String"},"sex":{"define":"sex","label":"性别：","name":"sex","relation":"sex","rules":{"integer":true},"type":"Integer"},"street":{"define":"street","label":"街道：","name":"street","relation":"street","type":"String"}},"directDelete":false,"events":{},"idColumn":"id","initData":"[]","limit":20,"xid":"regData"});
 new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"sex":{"define":"sex","name":"sex","relation":"sex","type":"String"},"value":{"define":"value","name":"value","relation":"value","type":"String"}},"directDelete":false,"events":{},"idColumn":"sex","initData":"[{\"sex\":\"男\",\"value\":\"1\"},{\"sex\":\"女\",\"value\":\"0\"}]","limit":20,"xid":"sexData"});
 var justep = require('$UI/system/lib/justep');if(!this['__justep__']) this['__justep__'] = {};if(!this['__justep__'].selectOptionsAfterRender)	this['__justep__'].selectOptionsAfterRender = function($element) {		var comp = justep.Component.getComponent($element);		if(comp) comp._addDefaultOption();	};if(!this['__justep__'].selectOptionsBeforeRender)	this['__justep__'].selectOptionsBeforeRender = function($element) {		var comp = justep.Component.getComponent($element);		if(comp) comp._optionsBeforeRender();	};
}}); 
return __result;});