define(function(require){
require('$model/UI2/system/components/justep/model/model');
require('$model/UI2/system/components/justep/loadingBar/loadingBar');
require('$model/UI2/system/components/justep/button/button');
require('$model/UI2/system/components/justep/row/row');
require('$model/UI2/system/components/justep/output/output');
require('$model/UI2/system/components/justep/titleBar/titleBar');
require('$model/UI2/system/components/justep/panel/child');
require('$model/UI2/system/components/justep/data/data');
require('$model/UI2/system/components/justep/windowDialog/windowDialog');
require('$model/UI2/system/components/justep/window/window');
require('$model/UI2/system/components/justep/panel/panel');
var __parent1=require('$model/UI2/system/lib/base/modelBase'); 
var __parent0=require('$model/UI2/Ljrecy/2/mcAccount'); 
var __result = __parent1._extend(__parent0).extend({
	constructor:function(contextUrl){
	this.__sysParam='true';
	this.__contextUrl=contextUrl;
	this.__id='';
	this.__cid='c2imEV3';
	this._flag_='199428e8a39f233fb743420875c6c781';
	this.callParent(contextUrl);
 var __Data__ = require("$UI/system/components/justep/data/data");new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"id":{"define":"id","label":"list_id","name":"id","relation":"id","type":"String"},"name":{"define":"name","label":"显示名称","name":"name","relation":"name","type":"String"},"ref":{"define":"ref","label":"数据库名称","name":"ref","relation":"ref","type":"String"}},"directDelete":false,"events":{},"idColumn":"id","initData":"[{\"id\":\"1\",\"ref\":\"\",\"name\":\"头像\"},{\"id\":\"2\",\"name\":\"用户名\"},{\"id\":\"3\",\"name\":\"姓名\"},{\"id\":\"4\",\"name\":\"性别\"},{\"id\":\"5\",\"name\":\"身份证号\"},{\"id\":\"6\",\"name\":\"所在地\"},{\"id\":\"7\",\"name\":\"个性签名\"}]","limit":20,"xid":"data1"});
 new __Data__(this,{"autoLoad":true,"confirmDelete":true,"confirmRefresh":true,"defCols":{"id":{"define":"id","name":"id","relation":"id","rules":{"integer":true},"type":"Integer"},"idCard":{"define":"idCard","name":"idCard","relation":"idCard","type":"String"},"local":{"define":"local","name":"local","relation":"local","type":"String"},"name":{"define":"name","name":"name","relation":"name","type":"String"},"sex":{"define":"sex","name":"sex","relation":"sex","type":"String"},"sign":{"define":"sign","name":"sign","relation":"sign","type":"String"},"usrName":{"define":"usrName","name":"usrName","relation":"usrName","type":"String"}},"directDelete":false,"events":{},"idColumn":"id","initData":"[{\"id\":1,\"usrName\":\"zhsh@163.com\",\"name\":\"张帅\",\"idCard\":\"106320199407267840\",\"sex\":\"男\",\"local\":\"中国广东省广州市\",\"sign\":\"环保从我们做起！\"}]","limit":20,"xid":"data2"});
}}); 
return __result;});