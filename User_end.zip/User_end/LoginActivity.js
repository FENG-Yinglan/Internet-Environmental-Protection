define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	require("$UI/system/lib/cordova/cordova");
	require("cordova!cordova-plugin-console");
	var sendJson = require("$UI/Ljrecy/sendJson");
	var Model = function(){
		this.callParent();
	};
	
	//图片路径转换
	Model.prototype.toUrl = function(url){
		return url ? require.toUrl(url) : "";
	};

	function saveUsrInfo(ret){
		localStorage.setItem("area",ret.area);
		localStorage.setItem("city",ret.city);
		localStorage.setItem("head",ret.head);
		localStorage.setItem("idcard",ret.idcard);
		localStorage.setItem("province",ret.province);
		localStorage.setItem("score",ret.score);
		localStorage.setItem("sex",ret.sex);
		localStorage.setItem("signature",ret.signature);
		localStorage.setItem("street",ret.street);
		localStorage.setItem("token",ret.token);
		localStorage.setItem("name",ret.username);
		localStorage.setItem("nickName",ret.nickname);
	};

	Model.prototype.loginBtnClick = function(event){
		var username = this.comp("nameInput").val();
		var password = this.comp("passwordInput").val();
		var remmeT = this.comp("remmeToggle").checked;
		var msgDg = this.comp("messageDialog1");
		var receiver = this.comp("windowReceiver1");
		if (username.length === 0 || password.length === 0){
			msgDg.show({"title":"错误","message":"密码或用户名不能为空"});
		}
		else{
			var params = {
	                "name":username,
	                "password":password,
	                };
	        var success = function(resultData,xhr){
	            if(resultData.errorno === 0){
	            	msgDg.show({"title":"登录成功"});
	            	saveUsrInfo(resultData.data);
	            	localStorage.setItem("username",username);
	            	localStorage.setItem("loginStatus",1);
	            	if (remmeT === 1){
	            		localStorage.setItem("password",password);
	            		localStorage.setItem("remMe",1);
	            	}
	            	else{
	            		localStorage.setItem("remMe",0);
	            	}
	            	receiver.windowEnsure();
	            }
	            else{
	            	msgDg.show({"title":"错误","message":"密码或用户名错误"});
	            }
	        };
	        sendJson.sendRequest({
	        	"baseUrl":"http://aliy.w3.luyouxia.net",
	            "url" : "/mUser", // servlet请求地址
	            "action" : "login", // action
	            "params" : params, // action对应的参数
	            "success" : success // 请求成功后的回调方法
	        });
		}
        
	};

	Model.prototype.jumpToRegisterPage = function(event){
		this.comp("windowDialog1").open();
	};

	Model.prototype.windowReceiver1Receive = function(event){
		if (localStorage.getItem("remMe") == 1){
//			console.log("you had set storage data");
			this.comp("nameInput").val(localStorage.getItem("username"));
			this.comp("passwordInput").val(localStorage.getItem("password"));
		}
	};

	return Model;
});