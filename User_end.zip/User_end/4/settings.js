define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");

	var Model = function(){
		this.callParent();
	};
	Model.prototype.about = function(event){
		this.comp("windowDialog1").open({"src": require.toUrl("about.w")});
	};
	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};
	return Model;
});