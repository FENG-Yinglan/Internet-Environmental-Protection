define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	var sendJson = require("$UI/Ljrecy/sendJson");
	require("$UI/system/lib/cordova/cordova");
	require("css!$UI/demo/native/common/pub").load();
	require("cordova!phonegap-plugin-barcodescanner");
	
	var Model = function(){
		this.callParent();
	};
	
	function saveUsrInfo(result){
		var ret = result.data;
		localStorage.setItem("area",ret.area);
		localStorage.setItem("city",ret.city);
		localStorage.setItem("head",ret.head);
		localStorage.setItem("idcard",ret.idcard);
		localStorage.setItem("province",ret.province);
		localStorage.setItem("score",ret.score);
		localStorage.setItem("sex",ret.sex);
		localStorage.setItem("signature",ret.signature);
		localStorage.setItem("street",ret.street);
		localStorage.setItem("token",ret.token);
		localStorage.setItem("name",ret.username);
	};
	
	Model.prototype.getImageUrl = function(row){
		return require.toUrl(row.val('imgSrc'));
	};
	
	Model.prototype.open = function(event,id) {
	var chlidPageWinDig = this.comp("windowDialog1");
	var Xid = event.source.getXid();	
	switch(Xid){
	case "button1":
		//this.comp("mmmm").show({"title":"点击","message":"点击了1"})
		chlidPageWinDig.open({"src":require.toUrl("../1/printTagStatus.w")});
	break;
	case "button2":
		chlidPageWinDig.open({"src":require.toUrl("../2/mcAccount.w")});
	break;
	case "button3":
		chlidPageWinDig.open({"src":require.toUrl("../3/myWallet.w")});
	break;
	case "button4":
		chlidPageWinDig.open({"src":require.toUrl("../4/settings.w")});
	break;
	
	}
	};
	
	Model.prototype.scanBtnClick = function(event){
		this.comp("mmmm").show({});
		
		var me = this;
		function scanSu(result,xhr){
			if(result.errorno === 0){
				me.comp("mmmm").show({"title":"登录成功"});
			}
			else{
				me.comp("mmmm").show({"title":"系统错误"});
			}
		}
		function onSuccess(result) {
			//me.comp("mmmm").show({"title":"扫描成功","message":result.format+" "+result.text});
			var token = localStorage.getItem("token");
			var params = {"token":token,"qrCode":result.text};
			sendJson.sendRequest({
	        	"baseUrl":"http://aliy.w3.luyouxia.net",
	            "url" : "/mUser", // servlet请求地址
	            "action" : "qrCode", // action
	            "params" : params, // action对应的参数
	            "success" :  scanSu// 请求成功后的回调方法
			});
		}
		
		function onError(error) {
			me.comp("mmmm").show({"title":"扫描失败","message":result.format+" "+result.text});
		}
		
		cordova.plugins.barcodeScanner.scan(onSuccess, onError);
		
	};
	
	
	Model.prototype.modelLoad = function(event){
		var token = localStorage.getItem("token");
		if (token.length === 0 || localStorage.getItem("name").length === 0){
			if (token.length === 0){
				localStorage.setItem("loginStatus",0);
				alert("程序出错，请重新登录");
				justep.Shell.showPage(require.toUrl("../login.w"));
			}
			else{
				var params = {"token":token};
				sendJson.sendRequest({
		        	"baseUrl":"http://aliy.w3.luyouxia.net",
		            "url" : "/mUser", // servlet请求地址
		            "action" : "info", // action
		            "params" : params, // action对应的参数
		            "success" :  saveUsrInfo// 请求成功后的回调方法
				});
			}
		}
		
		var name = localStorage.getItem("name");
		var username = localStorage.getItem("username");
		
		$("img[xid=image1]").attr("src","http://aliy.w3.luyouxia.net/mUser/headImg?token="+token);
		$("span[xid=label1]").text(name);
		$("span[xid=label2]").text(username);
	};
	
	
	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};
	
	
	return Model;
});