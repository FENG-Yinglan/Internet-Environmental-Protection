define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");

	var Model = function(){
		this.callParent();
	};

	Model.prototype.modelLoad = function(event){

	};

	Model.prototype.confirm = function(event){
		localStorage.setItem("province", this.comp("provinceSelect1").val());
		localStorage.setItem("city", this.comp("citySelect1").val());
		localStorage.setItem("area", this.comp("districtSelect1").val());
		localStorage.setItem("street", this.comp("input1").val());
		this.comp("windowReceiver1").windowEnsure();
	};

	Model.prototype.windowReceiver1Receive = function(event){
		//alert("halt");
//		this.comp("data1").setValue(0, "广东省", 0);
//		this.comp("provinceSelect1").update();
		this.comp("data1").clear();
		this.comp("data1").add({col0:localStorage.getItem("province"),
		col1:localStorage.getItem("city"),
		col2:localStorage.getItem("area")});
		
		this.comp("input1").val(localStorage.getItem("street"));
	};

	return Model;
});