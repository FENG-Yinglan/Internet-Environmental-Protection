define(function(require){
	var $ = require("jquery");
	var justep = require("$UI/system/lib/justep");
	require("$UI/system/lib/cordova/cordova");                
	require("cordova!cordova-plugin-camera");
	var MsgDialog = require("$UI/system/components/justep/messageDialog/messageDialog");
	var sendJson = require("$UI/Ljrecy/sendJson");
	var changeOp = "";
	var msgdig = null;

	var Model = function(){
		this.callParent();
	};
	
	Model.prototype.changeInfo = function(event){
		var xid = event.currentTarget.getAttribute("xid");
		msgdig = this.comp("messageDialog1");
		switch(xid){
			case "imgcol":
				navigator.camera.getPicture(getPicSuccess, getPicFail,  { 
                  mediaType : 0,//只选择图片
                  quality:80,
                  allowEdit:true,
                  targetWidth:100,
                  targetHeight:100,                 
                  destinationType: navigator.camera.DestinationType.DATA_URL,                            
                  sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
              //sourceType: navigator.camera.PictureSourceType.PhotoAlbum//在安卓中，这个参数会跳出拍照界面
				});
           		function getPicSuccess(imgData){};
           		function getPicFail(message){alert("upload fail:"+message);};
           
			case "usrNameCol":
				changeOp = "usrNameOp";
				if (!this.msgdig1){this.msgdig1 = new MsgDialog({
				parentNode : this.getElementByXid("content1")
				});}
				this.msgdig1.on("onOK",Model.prototype.MsgDigOK,this);
				this.msgdig1.show({
					type:"Prompt",
					title:"请输入",
					message:"你的新用户名:",
					width:'',
					inputValue:"",
				});
				break;
			case "localcol":
				changeOp = "localOp";
				this.comp("windowDialog1").open();
				break;
			case "signcol":
				changeOp = "signOp";
				if(!this.msgdig3){this.msgdig3 = new MsgDialog({
				parentNode : this.getElementByXid("content1")
				});}
				this.msgdig3.on("onOK",Model.prototype.MsgDigOK,this);
				this.msgdig3.show({
					type:"Prompt",
					title:"请输入",
					message:"你的新签名:",

				});
				break;
		}
	}
	
	function saveUsrInfo(result){
		var ret = result.data;
		localStorage.setItem("area",ret.area);
		localStorage.setItem("city",ret.city);
		localStorage.setItem("head",ret.head);
		localStorage.setItem("idcard",ret.idcard);
		localStorage.setItem("province",ret.province);
		localStorage.setItem("score",ret.score);
		localStorage.setItem("sex",ret.sex);
		localStorage.setItem("signature",ret.signature);
		localStorage.setItem("street",ret.street);
		localStorage.setItem("token",ret.token);
		localStorage.setItem("name",ret.username);
		localStorage.setItem("nickName",ret.nickname);
	};
	
	function updataInfo(){
		var params = {
				"token":localStorage.getItem("token"),
				"nickName":localStorage.getItem("nickName"),
				"province":localStorage.getItem("province"),
				"city":localStorage.getItem("city"),
				"area":localStorage.getItem("area"),
				"street":localStorage.getItem("street"),
				"signature":localStorage.getItem("signature")
				
		};
		sendJson.sendRequest({
        	"baseUrl":"http://aliy.w3.luyouxia.net",
            "url" : "/mUser", // servlet请求地址
            "action" : "updateUser", // action
            "params" : params, // action对应的参数
        });
	}
	
	Model.prototype.MsgDigOK = function(event){
		var value = event.input;
		if (changeOp.length != 0)
		{
			this.comp(changeOp).set("value", value);
			if("signOp" === changeOp){localStorage.setItem("signature",value);}
			updataInfo();
		}
	}
	Model.prototype.modelLoad = function(event){
		var token = localStorage.getItem("token");
		var params = {"token":token};
		sendJson.sendRequest({
	        "baseUrl":"http://aliy.w3.luyouxia.net",
	        "url" : "/mUser", // servlet请求地址
	        "action" : "info", // action
	        "params" : params, // action对应的参数
	        "success" :  saveUsrInfo// 请求成功后的回调方法
	        });	
		this.comp("data2").clear();
		var image = this.getElementByXid("image1");
		$(image).attr("src","http://aliy.w3.luyouxia.net/mUser/headImg?token="+localStorage.getItem("token"));
		this.comp("data2").add({
			usrName:localStorage.getItem("username"),
			name:localStorage.getItem("name"),
			idCard:localStorage.getItem("idcard"),
			sex:localStorage.getItem("sex") === 0?"女":"男",
			local:localStorage.getItem("province")+localStorage.getItem("city")+localStorage.getItem("area")+localStorage.getItem("street"),
			sign:localStorage.getItem("signature")
		});
	};
	Model.prototype.windowDialog1Received = function(event){
		this.comp("data2").clear();
		this.comp("data2").add({
			usrName:localStorage.getItem("username"),
			name:localStorage.getItem("name"),
			idCard:localStorage.getItem("idcard"),
			sex:localStorage.getItem("sex") === 0?"女":"男",
			local:localStorage.getItem("province")+localStorage.getItem("city")+localStorage.getItem("area")+localStorage.getItem("street"),
			sign:localStorage.getItem("signature")
		});
		updataInfo();
	};
	Model.prototype.backBtnClick = function(event){
		this.comp("windowReceiver1").windowEnsure();
	};
	return Model;
});